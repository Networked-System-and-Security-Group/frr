# MIDR 流量工程 + 负载均衡设计

## 概述

本文档详细说明 MIDR 如何利用 BGP-LS TED（Traffic Engineering Database）中的 TE 度量进行约束最短路径计算（CSPF），然后将计算结果转换为两级负载均衡策略下发到数据平面。

**核心思想**: TED 提供全网 TE 信息 → CSPF 基于约束计算最优路径 → 两级负载均衡器将路径转化为权重 → 数据平面按权重转发。

---

## 一、流量工程数据源：BGP-LS TED

### 1.1 TED 中的 TE 度量

FRR 的 TED（`lib/link_state.h`）为每条链路维护丰富的 TE 属性：

```c
/* lib/link_state.h — 每条链路的 TE 属性 */
struct ls_attributes {
    uint32_t flags;                     /* 哪些字段有效 */

    struct ls_standard {
        uint32_t te_metric;             /* TE 度量 (0-16777215) */
        uint32_t admin_group;           /* 管理组 (亲和力位图, 32-bit) */
        float    max_bw;                /* 最大链路带宽 (bytes/sec) */
        float    max_rsv_bw;            /* 最大可预留带宽 */
        float    unrsv_bw[8];           /* 每个优先级未预留带宽 */
        uint32_t remote_as;             /* 远端 AS 号 */
    } standard;

    struct ls_extended {
        uint32_t delay;                 /* 单向平均延迟 (微秒) */
        uint32_t min_delay;             /* 单向最小延迟 */
        uint32_t max_delay;             /* 单向最大延迟 */
        uint32_t jitter;                /* 延迟抖动 (微秒) */
        uint32_t pkt_loss;              /* 丢包率 (×10^6, 即 ppm) */
        float    ava_bw;                /* 可用带宽 (bytes/sec) */
        float    rsv_bw;                /* 已预留带宽 */
        float    used_bw;               /* 已使用带宽 */
    } extended;

    uint32_t *srlgs;                    /* 共享风险链路组 (多个 ID) */
    uint8_t   srlg_len;                 /* SRLG 数量 */
};
```

### 1.2 TED 图结构

```
ls_ted
├── vertices[]      ← 网络节点 (路由器)
│   ├── node        ← ls_node (节点属性: router-id, SRGB, SRv6)
│   ├── outgoing_edges[] ← 出向链路
│   └── incoming_edges[] ← 入向链路
│
├── edges[]         ← 网络链路 (单向)
│   ├── source      ← 源节点指针
│   ├── destination ← 目的节点指针
│   └── attributes  ← ls_attributes (TE 度量, 见上)
│
└── subnets[]       ← 前缀信息
    ├── vertex      ← 归属节点
    └── ls_pref     ← ls_prefix (前缀/算法/SID)
```

### 1.3 TE 度量如何在 FRR 中收集

```
OSPF/ISIS TE 扩展
    │ 携带 TE 属性(延迟、带宽、SRLG...)
    ▼
zebra/link_state.c
    │ 将 TE 属性编码为 Link State 消息
    ▼ ZAPI OPAQUE 消息
    │
bgpd/bgp_ls_ted.c
    │ 解析 Link State 消息
    │ → ls_vertex_add/ls_edge_update → 存入 TED
    │ → 同时发布 BGP-LS NLRI 给 IBGP 邻居
    ▼
全网 BGP-LS TED 同步完成
```

---

## 二、CSPF（约束最短路径优先）计算

### 2.1 CSPF 输入

```
输入:
  - 目的前缀 P (可以是 IP 前缀或 SRv6 SID)
  - TED 图 G(V, E)
  - 约束条件 C:
    - 最大延迟 (max_delay)
    - 最小带宽 (min_bw)
    - 亲和力 (include-any / exclude-any / include-all)
    - 避免 AS 列表
    - 避免 SRLG 列表
    - 优先级 (setup-priority / hold-priority)

输出:
  - K 条最优路径 (K 由配置决定, 默认 4)
  - 每条路径:
    - 路径节点列表 [R1, R2, ..., Rn]
    - 总度量 (IGP / TE / 复合)
    - SID 列表 (如使用 SRv6)
    - 瓶颈带宽 / 路径延迟
```

### 2.2 度量函数

MIDR 支持多种度量函数，用户可配置：

```c
/* bgpd/bgp_midr_cspf.h — CSPF 度量函数 */

enum midr_cspf_metric_type {
    MIDR_CSPF_METRIC_IGP,       /* 标准 IGP 度量 (默认) */
    MIDR_CSPF_METRIC_TE,        /* TE 度量 */
    MIDR_CSPF_METRIC_DELAY,     /* 延迟度量 (微秒) */
    MIDR_CSPF_METRIC_JITTER,    /* 抖动度量 */
    MIDR_CSPF_METRIC_HOP,       /* 跳数 */
    MIDR_CSPF_METRIC_COMPOUND,  /* 复合度量: w1*IGP + w2*delay + w3*TE */
};

/* 复合度量权重 */
struct midr_cspf_compound_weights {
    float w_igp;        /* IGP 权重 (默认 1.0) */
    float w_te;         /* TE 权重 (默认 0.0) */
    float w_delay;      /* 延迟权重 (默认 0.0) */
    float w_hop;        /* 跳数权重 (默认 0.0) */
};
```

### 2.3 CSPF 算法

MIDR 使用 **K-最短路径 + 剪枝** 算法：

```c
/* bgpd/bgp_midr_cspf.c — CSPF 核心算法 */

struct midr_cspf_result {
    uint8_t   path_count;               /* 找到的路径数 */
    struct midr_cspf_path paths[MIDR_MAX_PATHS];
};

struct midr_cspf_path {
    /* 路径信息 */
    uint32_t  metric;                   /* 路径总度量 */
    uint32_t  te_metric;                /* TE 度量 */
    uint32_t  delay;                    /* 总延迟 (us) */
    float     avail_bw;                 /* 瓶颈可用带宽 */
    uint8_t   hop_count;                /* 跳数 */

    /* 节点列表 (用于调试/验证) */
    uint8_t   node_count;
    uint64_t  node_keys[MAX_HOPS];      /* TED vertex keys */

    /* SID 列表 (SRv6 时) */
    uint8_t   sid_count;
    struct in6_addr sid_list[SRV6_MAX_SEGS];
};

/* CSPF 主函数 */
int midr_cspf_compute(struct ls_ted *ted,
                      struct prefix *dst_prefix,
                      struct midr_cspf_constraints *constr,
                      struct midr_cspf_result *result)
{
    /* Step 1: 剪枝 (prune) — 排除不满足约束的链路 */
    for (int i = 0; i < ted->edges.count; i++) {
        struct ls_edge *edge = ted->edges[i];

        /* 带宽约束 */
        if (constr->min_bw > 0 &&
            edge->attributes->extended.ava_bw < constr->min_bw)
            SET_FLAG(edge->flags, EDGE_FLAG_PRUNED);

        /* 延迟约束 */
        if (constr->max_delay > 0 &&
            edge->attributes->extended.delay > constr->max_delay)
            SET_FLAG(edge->flags, EDGE_FLAG_PRUNED);

        /* 亲和力约束 */
        if (constr->affinity_type != AFFINITY_NONE) {
            if (!midr_cspf_check_affinity(
                    edge->attributes->standard.admin_group,
                    constr->affinity, constr->affinity_type))
                SET_FLAG(edge->flags, EDGE_FLAG_PRUNED);
        }

        /* SRLG 约束 */
        if (constr->avoid_srlgs) {
            if (midr_cspf_check_srlg_overlap(
                    edge->attributes->srlgs,
                    edge->attributes->srlg_len,
                    constr->avoid_srlgs))
                SET_FLAG(edge->flags, EDGE_FLAG_PRUNED);
        }

        /* AS 约束 */
        if (constr->avoid_as_count &&
            midr_cspf_check_as(edge->attributes->standard.remote_as,
                               constr->avoid_as, constr->avoid_as_count))
            SET_FLAG(edge->flags, EDGE_FLAG_PRUNED);
    }

    /* Step 2: 运行 K-SPF (Yen's algorithm) */
    /* 度量函数由 constr->metric_type 决定 */
    midr_cspf_yen_k_shortest(ted, constr, K_PATH_COUNT, result);

    /* Step 3: 为每条路径构造 SID 列表 (如需要) */
    if (constr->use_srv6) {
        for (int i = 0; i < result->path_count; i++)
            midr_cspf_build_sid_list(ted, &result->paths[i]);
    }

    return result->path_count;
}
```

### 2.4 亲和力（Affinity）约束

亲和力（Administrative Group / Color）用于基于链路颜色的路径选择：

```c
/* bgpd/bgp_midr_cspf.c — 亲和力检查 */

enum affinity_type {
    AFFINITY_NONE,          /* 不检查 */
    AFFINITY_INCLUDE_ANY,   /* 包含任意指定颜色 */
    AFFINITY_INCLUDE_ALL,   /* 包含所有指定颜色 */
    AFFINITY_EXCLUDE_ANY,   /* 排除任意指定颜色 */
};

bool midr_cspf_check_affinity(uint32_t link_affinity,
                               uint32_t required_affinity,
                               enum affinity_type type)
{
    switch (type) {
    case AFFINITY_INCLUDE_ANY:
        return (link_affinity & required_affinity) != 0;
    case AFFINITY_INCLUDE_ALL:
        return (link_affinity & required_affinity) == required_affinity;
    case AFFINITY_EXCLUDE_ANY:
        return (link_affinity & required_affinity) == 0;
    default:
        return true;
    }
}
```

---

## 三、TE 度量到负载均衡权重的转换

### 3.1 整体流程

```
TED (全网 TE 信息)
  │
  ▼
CSPF (受约束路径计算)
  │ 输出: K 条路径 + 每条路径的度量/延迟/带宽
  ▼
midr_lb_compute_group_weights()
  │ 基于 Group 级度量计算 group 间权重
  ▼
midr_lb_merge_weights()
  │ 合并 group 权重 + 路径权重 → 最终权重
  ▼
midr_zebra_route_add()
  │ 填充 zapi_nexthop[].weight
  ▼
Linux Kernel FIB (nexthop group with weights)
```

### 3.2 多种权重计算的算法

```c
/* bgpd/bgp_midr_lb.c — 基于 TE 度量的权重计算 */

/* 1. 按可用带宽加权 (Bandwidth-aware UCMP) */
static void midr_lb_weight_by_bandwidth(struct midr_path_ext *paths,
                                         uint8_t count)
{
    float total_bw = 0;

    /* 累加所有路径的瓶颈带宽 */
    for (int i = 0; i < count; i++)
        total_bw += paths[i].avail_bw;

    /* 按带宽比例分配权重 */
    for (int i = 0; i < count; i++) {
        uint16_t w = (uint16_t)(paths[i].avail_bw / total_bw * 255);
        paths[i].weight = (uint8_t)(w ? w : 1);  /* 最小 1 */
    }
}

/* 2. 按延迟倒数加权 (Delay-inverse UCMP) */
static void midr_lb_weight_by_delay(struct midr_path_ext *paths,
                                     uint8_t count)
{
    float total_inv_delay = 0;

    for (int i = 0; i < count; i++)
        total_inv_delay += paths[i].te_metric > 0 ?
                           1.0f / paths[i].te_metric : 0;

    for (int i = 0; i < count; i++) {
        float inv = paths[i].te_metric > 0 ?
                    1.0f / paths[i].te_metric : 0;
        uint16_t w = (uint16_t)(inv / total_inv_delay * 255);
        paths[i].weight = (uint8_t)(w ? w : 1);
    }
}

/* 3. 复合权重 (可定制) */
static void midr_lb_weight_compound(struct midr_path_ext *paths,
                                     uint8_t count,
                                     struct midr_lb_tune *tune)
{
    float scores[MIDR_MAX_PATHS] = {};
    float total_score = 0;

    for (int i = 0; i < count; i++) {
        float bw_score = paths[i].avail_bw / tune->ref_bw;
        float delay_score = tune->ref_delay /
            (paths[i].te_metric > 0 ? paths[i].te_metric : 1);
        float hop_score = (float)MAX_HOPS / paths[i].hop_count;

        /* 加权综合得分 */
        scores[i] = tune->w_bw * bw_score +
                    tune->w_delay * delay_score +
                    tune->w_hop * hop_score;
        total_score += scores[i];
    }

    for (int i = 0; i < count; i++) {
        uint16_t w = (uint16_t)(scores[i] / total_score * 255);
        paths[i].weight = (uint8_t)(w ? w : 1);
    }
}
```

### 3.3 Group 级 TE 度量聚合

对于跨 Group 转发，需要将 Group 内多条链路的 TE 度量聚合为 Group 级度量：

```c
/* bgpd/bgp_midr_te.c — Group 级 TE 聚合 */

struct midr_group_te_metrics {
    uint8_t  group_id;

    /* 聚合度量 (最小值 / 平均值 / 瓶颈值) */
    uint32_t agg_metric;            /* IGP 度量 (瓶颈: 取路径最大值) */
    uint32_t agg_te_metric;         /* TE 度量 (瓶颈) */
    uint32_t agg_delay;             /* 延迟 (累加, 端到端) */
    float    ava_bw;                /* 可用带宽 (瓶颈: 取链路最小值) */
    float    max_bw;                /* 最大带宽 (瓶颈) */
    uint8_t  agg_hop;               /* 跳数 (累加) */

    /* 出口路由器列表 */
    uint8_t  egress_router_count;
    uint64_t egress_router_keys[MAX_EGRESS_ROUTERS];
};

/* 从 Group 内所有路径聚合 TE 信息 */
void midr_te_aggregate_group(struct ls_ted *ted,
                              uint8_t group_id,
                              uint64_t *group_vertices,
                              uint8_t vertex_count,
                              struct midr_group_te_metrics *agg)
{
    agg->group_id = group_id;
    agg->ava_bw = FLT_MAX;
    agg->agg_delay = 0;
    agg->agg_hop = 0;

    for (int i = 0; i < vertex_count; i++) {
        struct ls_vertex *v = ls_find_vertex_by_key(ted, group_vertices[i]);
        if (!v) continue;

        for (struct listnode *ln = listhead(v->outgoing_edges);
             ln; ln = listnextnode(ln)) {
            struct ls_edge *e = listgetdata(ln);
            struct ls_vertex *dst = e->destination;

            /* 只计算 Group 内的链路 */
            if (!midr_te_is_vertex_in_group(dst, group_id))
                continue;

            struct ls_attributes *attr = e->attributes;

            /* 瓶颈带宽: 取最小值 */
            if (attr->extended.ava_bw < agg->ava_bw)
                agg->ava_bw = attr->extended.ava_bw;

            /* 端到端延迟: 累加 */
            agg->agg_delay += attr->extended.delay;

            /* TE 度量: 累加 */
            agg->agg_te_metric += attr->standard.te_metric;
        }
        agg->agg_hop++;
    }
}
```

---

## 四、实时负载调谐

### 4.1 链路利用率监测

```c
/* bgpd/bgp_midr_lb_tune.c — 实时负载调谐 */

struct midr_lb_tune {
    bool            enable;         /* 启用实时调谐 */
    uint16_t        interval;       /* 检查间隔 (秒, 默认 30) */
    uint8_t         up_threshold;   /* 上调阈值 (% , 默认 80%) */
    uint8_t         down_threshold; /* 下调阈值 (% , 默认 20%) */
    float           adjust_step;    /* 调整步长 (比例, 默认 0.1) */

    /* 统计 */
    uint32_t        adjustment_count;
    uint32_t        last_adjustment_ts;
};
```

### 4.2 调谐算法

```
每 30 秒:
  1. 查询每条路径的出口接口统计 (zebra 提供)
     - if stats->output_rate / if stats->bandwidth × 100%

  2. 对每个目的前缀:
     - 计算每条路径的利用率
     - 如果所有路径利用率在 40%-60% 之间: 不做调整
     - 如果某路径利用率 > 80% (过载):
       * 降低该路径权重 10%
       * 将释放的流量平摊到其他路径
     - 如果某路径利用率 < 20% (轻载):
       * 可以适当增加权重 (预留余量用于故障切换)

  3. 调整完成后:
     - 重新计算权重
     - 通过 midr_zebra_route_add() 下发新权重
     - 内核自动按新权重重新分配流量 (无缝切换)
```

```c
/* 核心调谐逻辑 */
void midr_lb_tune_adjust(struct bgp *bgp,
                          struct prefix *p,
                          struct midr_path_ext *paths,
                          uint8_t path_count)
{
    float *utilizations = XCALLOC(MTYPE_TMP, sizeof(float) * path_count);
    float total_bw = 0, total_util = 0;

    /* Step 1: 收集路径利用率 */
    for (int i = 0; i < path_count; i++) {
        if (paths[i].max_bw > 0) {
            struct interface *ifp = if_lookup_by_index(
                paths[i].ifindex, bgp->vrf_id);
            if (ifp && ifp->stats)
                utilizations[i] =
                    (float)ifp->stats->output_rate / paths[i].max_bw;
        }
    }

    /* Step 2: 检测过载路径 */
    for (int i = 0; i < path_count; i++) {
        if (utilizations[i] > 0.8 && paths[i].weight > 1) {
            /* 路径 i 过载: 降低权重 */
            uint8_t decrease = MAX(1, paths[i].weight * 0.1);
            paths[i].weight -= decrease;
            total_bw += decrease;
        }
    }

    /* Step 3: 将释放的权重重新分配 */
    if (total_bw > 0) {
        int underloaded = 0;
        for (int i = 0; i < path_count; i++) {
            if (utilizations[i] < 0.6)
                underloaded++;
        }
        if (underloaded > 0) {
            uint8_t add = (uint8_t)(total_bw / underloaded);
            for (int i = 0; i < path_count; i++) {
                if (utilizations[i] < 0.6)
                    paths[i].weight += add;
            }
        }

        /* Step 4: 下发新权重 */
        midr_zebra_route_add(bgp, p, ...);
    }

    XFREE(MTYPE_TMP, utilizations);
}
```

### 4.3 链路利用率获取路径

```
bgpd (定期定时器)
  │
  ├── 方式 1: ZEBRA_INTERFACE_LINK_PARAMS
  │   zebra 定期上报接口统计 (速率/错误/drops)
  │
  └── 方式 2: ZEBRA_IPMR_ROUTE_STATS
      zebra 提供 per-prefix 流量统计
      │
      ▼
  midr_lb_tune_adjust()
      │ 计算各路径利用率
      ▼
  midr_zebra_route_add()
      │ 下发新权重
      ▼
  内核 nexthop group weight 更新 → 流量重分配
```

---

## 五、TE + LB 综合示例

### 5.1 场景

```
         ┌────1ms/100M─── R2 ───3ms/50M───┐
  R1 ────┤                                 ├──── R4 (目的: 10.0.0.0/24)
         └────5ms/200M─── R3 ───2ms/80M───┘

路径 1: R1→R2→R4: 延迟=4ms, 带宽=50Mbps
路径 2: R1→R3→R4: 延迟=7ms, 带宽=80Mbps
```

### 5.2 Step 1: CSPF 计算

```c
/* 输入: TE 约束 */
struct midr_cspf_constraints constr = {
    .metric_type = MIDR_CSPF_METRIC_DELAY,  /* 最小化延迟 */
    .min_bw = 40.0f,                         /* 至少 40Mbps */
};

/* CSPF 输出: 2 条路径 */
struct midr_cspf_result result;
midr_cspf_compute(ted, &prefix_10_0_0_0_24, &constr, &result);

/* result:
 *   path[0]: metric=4ms,  avail_bw=50M, hop=2  [R1,R2,R4]
 *   path[1]: metric=7ms,  avail_bw=80M, hop=2  [R1,R3,R4]
 */
```

### 5.3 Step 2: TE 度量 → 权重

```c
/* CSPF 结果 → midr_path_ext */
struct midr_path_ext paths[2] = {
    { .nexthop = R2_addr, .avail_bw = 50, .te_metric = 4,  .hop_count = 2 },
    { .nexthop = R4_addr, .avail_bw = 80, .te_metric = 7,  .hop_count = 2 },
};

/* 按带宽加权: 50 / (50+80) * 255 = 98,  80/130*255 = 157 */
/* 按延迟加权: (1/4)/(1/4+1/7)*255 = 162,  (1/7)/0.3929*255 = 93 */

/* 复合加权 (w_bw=0.5, w_delay=0.5): */
/*   path[0]: 0.5*(50/130) + 0.5*((1/4)/(1/4+1/7)) = 0.510 → weight=130 */
/*   path[1]: 0.5*(80/130) + 0.5*((1/7)/(1/4+1/7)) = 0.490 → weight=125 */
midr_lb_weight_compound(paths, 2, &(struct midr_lb_tune){
    .ref_bw = 100, .ref_delay = 10, .w_bw = 0.5, .w_delay = 0.5
});
```

### 5.4 Step 3: 数据平面下发

```c
/* 内核效果: */
/* ip route add 10.0.0.0/24
 *   nexthop via R2_addr weight 130
 *   nexthop via R4_addr weight 125
 */

/* 流量分配:
 *   path[0] 占比: 130/(130+125) ≈ 51%
 *   path[1] 占比: 125/(130+125) ≈ 49%
 *
 *   path[0] 延迟低(4ms)但带宽小(50M) → 分 51% 流量
 *   path[1] 延迟高(7ms)但带宽大(80M) → 分 49% 流量
 *
 * 效果: 总吞吐 = 50M×0.51 + 80M×0.49 ≈ 64.7Mbps
 *       纯 ECMP = (50M+80M)/2 = 65Mbps (相同)
 *       但延迟加权使得低延迟路径分到更多流量
 */
```

---

## 六、CLI 配置

### 6.1 CSPF 约束配置

```
midr-router(config)# midr traffic-engineering
midr-router(config-midr-te)# metric-type {igp | te | delay | jitter | compound}
midr-router(config-midr-te)# compound-weight igp 0.3
midr-router(config-midr-te)# compound-weight delay 0.4
midr-router(config-midr-te)# compound-weight te 0.3
midr-router(config-midr-te)# constraint max-delay 10000        ! 10ms
midr-router(config-midr-te)# constraint min-bandwidth 1000000  ! 1Gbps
midr-router(config-midr-te)# affinity include-any 0x01         ! 蓝色链路
midr-router(config-midr-te)# affinity exclude-any 0x02         ! 避免红色链路
midr-router(config-midr-te)# avoid-srlg 100 200               ! 避免 SRLG
midr-router(config-midr-te)# exit
```

### 6.2 负载均衡配置

```
midr-router(config)# midr load-balance
midr-router(config-midr-lb)# algorithm {ecmp | bandwidth | delay | compound}
midr-router(config-midr-lb)# tune enable
midr-router(config-midr-lb)# tune interval 30
midr-router(config-midr-lb)# tune up-threshold 80
midr-router(config-midr-lb)# tune down-threshold 20
midr-router(config-midr-lb)# tune adjust-step 0.1
midr-router(config-midr-lb)# exit
```

### 6.3 策略关联 TE

```
midr-router(config)# midr policy
midr-router(config-midr-policy)# policy-entry 100
midr-router(config-midr-policy-entry)# match dst-prefix 10.0.0.0/24
midr-router(config-midr-policy-entry)# match color 200
midr-router(config-midr-policy-entry)# action constrain-delay 10000
midr-router(config-midr-policy-entry)# action constrain-bandwidth 500000
midr-router(config-midr-policy-entry)# action lb-algo delay
midr-router(config-midr-policy-entry)# exit
```

### 6.4 监控命令

```
midr-router# show midr te database                    ! 查看 TED
midr-router# show midr te database links              ! 查看所有链路 TE 度量
midr-router# show midr te database link 10.0.0.1      ! 查看特定链路
midr-router# show midr cspf 10.0.0.0/24              ! 查看 CSPF 计算结果
midr-router# show midr cspf 2001:db8::/48 constrain delay 5000
midr-router# show midr load-balance                   ! 查看 LB 状态
midr-router# show midr load-balance statistics        ! 查看 LB 统计
midr-router# show midr load-balance tune              ! 查看调谐状态
midr-router# show ip route te                         ! 查看 TE 路由
```

---

## 七、性能评估

### 7.1 CSPF 计算复杂度

| 场景 | 节点数 | 边数 | CSPF 耗时 | 说明 |
|------|--------|------|-----------|------|
| 小型 Group | 10 | 30 | <1ms | 单次 K-SPF |
| 中型 Group | 50 | 200 | ~5ms | 单次 K-SPF |
| 大型 Group | 200 | 1000 | ~50ms | 单次 K-SPF |
| 大型网络 (全量) | 1000 | 5000 | ~500ms | 需增量 SPF |

### 7.2 负载均衡调谐开销

| 操作 | 频率 | 耗时 | 对转发影响 |
|------|------|------|-----------|
| 权重重新计算 | 每 30s | <1ms | 无 (内核原子更新 weight) |
| 链路利用率查询 | 每 30s | <1ms (ZAPI) | 无 |
| 路由更新下发 | 调谐时 | ~5ms (ZAPI) | 无缝 (nexthop group 更新) |

### 7.3 TE 度量存储开销

| 数据 | 每条链路 | 1000 条链路 |
|------|---------|------------|
| `ls_attributes` | ~500 bytes | ~500KB |
| `ls_edge` (含指针) | ~200 bytes | ~200KB |
| `ls_vertex` | ~300 bytes | ~300KB (1000 节点) |
| **总计** | | **~1MB** (1000 节点/链路) |

---

## 八、代码文件清单

| 文件 | 作用 | 关键函数 |
|------|------|---------|
| **`bgpd/bgp_midr_cspf.c/h`** | **CSPF 约束最短路径计算 (新增)** | `midr_cspf_compute()`, `midr_cspf_yen_k_shortest()` |
| **`bgpd/bgp_midr_te.c/h`** | **TE 度量管理、Group 聚合 (新增)** | `midr_te_aggregate_group()`, `midr_te_check_affinity()` |
| **`bgpd/bgp_midr_lb.c/h`** | **负载均衡权重计算 (新增)** | `midr_lb_weight_by_bandwidth()`, `midr_lb_weight_compound()` |
| **`bgpd/bgp_midr_lb_tune.c/h`** | **实时负载调谐 (新增)** | `midr_lb_tune_adjust()`, 定时器回调 |
| `lib/link_state.h` | TED 数据结构 | `struct ls_attributes`, `struct ls_edge` (复用) |
| `bgpd/bgp_ls_ted.c/h` | TED 管理 | `bgp_ls_process_vertex/edge/subnet()` (复用) |

---

## 九、与已有设计的关系

```
    TED (全网拓扑 + TE 度量)
     │
     ├── bgp_ls_ted.c        ← 已有: 管理 TED
     │
     ├── bgp_midr_cspf.c     ← 新增: CSPF 约束路径计算
     │    输出: 符合 TE 约束的 K 条路径
     │
     ├── bgp_midr_te.c       ← 新增: Group 级 TE 聚合
     │    输出: Group 级度量 (用于跨 Group 路由决策)
     │
     ├── bgp_midr_lb.c       ← 新增: 负载均衡权重计算
     │    输入: CSPF 路径 + TE 度量
     │    输出: 每路径 weight (1-255)
     │
     ├── bgp_midr_lb_tune.c  ← 新增: 实时调谐
     │    输入: 接口利用率统计
     │    输出: 调整后的权重
     │
     └── bgp_midr_zebra.c    ← 已有(增强): 下发权重到内核
          输出: zapi_nexthop[].weight + ZAPI_NEXTHOP_FLAG_WEIGHT