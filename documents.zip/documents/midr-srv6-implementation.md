# MIDR SRv6 实现详解

## 概述

本文档详细说明 SRv6（Segment Routing over IPv6）在 FRR 和 MIDR 中的完整实现链路：从 BGP-LS SID 学习、Locator 管理、ZAPI 编码、zebra 处理到 Linux 内核 Netlink 下发，以及 MIDR 如何利用 SRv6 实现跨 Group 隧道转发。

---

## 一、SRv6 在 FRR 中的整体架构

```
  BGP-LS UPDATE (RFC 9514 SRv6 SID NLRI)
           │
           ▼
  bgpd/bgp_ls_ted.c
  解析 SID NLRI → 存入 TED (ls_subnet->srv6)
           │
           ▼
  bgpd/bgp_srv6.c
  Locator 管理、Local SID 分配
           │
           ▼
  lib/zclient.c
  ZAPI 编码: zclient_send_localsid() / zclient_route_send()
           │
           ▼ ZAPI (Unix Domain Socket)
           │
           ▼
  zebra/zebra_rib.c → zebra_dplane.c → zebra/rt_netlink.c
           │
           ▼ Netlink
           │
  Linux Kernel FIB
  ┌─────────────────────────────────────────────┐
  │  两种 SRv6 Netlink 封装方式:                 │
  │  1. LWTUNNEL_ENCAP_SEG6      (Headend)      │
  │  2. LWTUNNEL_ENCAP_SEG6_LOCAL (Local SID)   │
  └─────────────────────────────────────────────┘
```

---

## 二、SRv6 核心概念回顾

### 2.1 SID (Segment Identifier)

SRv6 SID 是一个 128-bit IPv6 地址，包含：
- **Locator** (高64-96 bits): 路由定位符，用于路由到持有该 SID 的节点
- **Function** (剩余 bits): 指定节点要执行的操作（如 End.DT4、End.DT6）

### 2.2 两种 SID 类型

| 类型 | Linux Netlink Encap | 说明 | MIDR 用途 |
|------|-------------------|------|-----------|
| **Headend SID** | `LWTUNNEL_ENCAP_SEG6` | 在源节点封装 SRH，指定完整路径 | 跨 Group 隧道封装 |
| **Local SID** | `LWTUNNEL_ENCAP_SEG6_LOCAL` | 在中间节点安装本地 SID 行为 | Group 边界节点 Endpoint |

### 2.3 SRH (Segment Routing Header)

```
 0                   1                   2                   3
 0 1 2 3 4 5 6 7 8 9 0 1 2 3 4 5 6 7 8 9 0 1 2 3 4 5 6 7 8 9 0 1
+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
|  Next Header  |  Hdr Ext Len  |  Routing Type  |  Segments Left |
+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
|  Last Entry   |     Flags     |              Tag              |
+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
|                                                               |
|            Segment List[0] (128-bit IPv6 address)             |
|                                                               |
+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
|                                                               |
|            Segment List[1] (128-bit IPv6 address)             |
|                                                               |
+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
|                               ...                             |
+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
```

---

## 三、FRR SRv6 数据结构链

### 3.1 从 BGP-LS 学到远端 SID

```c
/* lib/srv6.h — SRv6 基本定义 */
#define SRV6_MAX_SIDS    16           /* 整个系统中 SID 上限 */
#define SRV6_MAX_SEGS    8            /* 单个 Segment List 上限 */

/* SRv6 Locator — 每个路由器配置 1 个 */
struct srv6_locator {
    char name[SRV6_LOCNAME_SIZE];     /* Locator 名称 */
    struct prefix_ipv6 prefix;        /* Locator 前缀 */
    uint8_t block_bits_length;        /* Block 长度 (bits) */
    uint8_t node_bits_length;         /* Node 长度 (bits) */
    uint8_t function_bits_length;     /* Function 长度 (bits) */
    uint8_t argument_bits_length;     /* Argument 长度 (bits) */
    uint8_t flags;                    /* SRV6_LOCATOR_USID, etc. */
};
```

### 3.2 BGPD 中的 SRv6 状态

```c
/* bgpd/bgpd.h — BGP 实例中的 SRv6 状态 */
struct bgp_srv6_unicast {
    uint8_t  flags;                   /* SRV6_POLICY_FLAG_SID_AUTO etc. */
    uint32_t sid_index;               /* 手动配置的 SID index */
    struct in6_addr *sid_explicit;    /* 显式 SID */
    struct in6_addr *sid;             /* 分配到的 SID */
    struct srv6_locator *sid_locator; /* 所属 Locator */
    struct in6_addr *zebra_sid_last_sent; /* 上次下发的 SID */
    char *rmap_name;                  /* route-map 名称 */
};
```

### 3.3 Nexthop 中的 SRv6 信息

```c
/* lib/nexthop.h — nexthop 中的 SRv6 */
struct nexthop {
    ...
    struct nh_srv6 *nh_srv6;          /* SRv6 相关信息 */
    ...
};

/* lib/nexthop.h — SRv6 封装信息 */
struct nh_srv6 {
    /* 模式 1: Headend (Segment List) */
    struct seg6_segs *seg6_segs;               /* SID 列表 */
    enum srv6_headend_behavior seg6_headend;   /* H.Insert / H.Encaps */

    /* 模式 2: Local SID (Endpoint Behavior) */
    enum seg6local_action_t seg6local_action;  /* End, End.X, End.DT4, etc. */
    struct seg6local_context seg6local_ctx;    /* 本地上下文 */
};
```

### 3.4 ZAPI 传输层

```c
/* lib/zclient.h — ZAPI nexthop (bgpd → zebra) */
struct zapi_nexthop {
    enum nexthop_types_t type;
    vrf_id_t vrf_id;
    ifindex_t ifindex;
    uint8_t flags;                    /* ZAPI_NEXTHOP_FLAG_SEG6 etc. */
    union { union g_addr gate; enum blackhole_type bh_type; };

    /* SRv6 Headend 行为 */
    int seg_num;                      /* Segment List 长度 */
    struct in6_addr seg6_segs[SRV6_MAX_SEGS]; /* SID 列表 */
    enum srv6_headend_behavior srv6_encap_behavior;

    /* SRv6 Local SID 行为 */
    uint32_t seg6local_action;        /* End.DT4, End.DT6, etc. */
    struct seg6local_context seg6local_ctx;   /* 本地上下文 */
};

/* ZAPI nexthop flags */
#define ZAPI_NEXTHOP_FLAG_SEG6      0x10  /* 标识 nexthop 包含 SRv6 Headend */
#define ZAPI_NEXTHOP_FLAG_SEG6LOCAL 0x20  /* 标识 nexthop 包含 Local SID */
```

---

## 四、SRv6 Headend 模式（跨 Group 隧道，MIDR 核心用途）

这是 MIDR 最常使用的 SRv6 模式——在源节点封装 SRH。

### 4.1 数据流

```
MIDR 控制平面:
    midr_path_result(.sid_count > 0, .sid_list[ ])
        │
        ▼
    midr_zebra_fill_srv6()
        │ 填充 znh->seg_num / znh->seg6_segs[]
        │ SET_FLAG(znh->flags, ZAPI_NEXTHOP_FLAG_SEG6)
        ▼
    zclient_route_send(ZEBRA_ROUTE_ADD, bgp_zclient, &api)
        │
        ▼ ZAPI
zebra/zapi_msg.c → zebra_rib.c → zebra_nhg.c → zebra_dplane.c
        │
        ▼
zebra/rt_netlink.c: _netlink_route_build_singlepath()
        │ 检测 nexthop->nh_srv6->seg6_segs
        │ 编码 LWTUNNEL_ENCAP_SEG6
        │
        ▼ Netlink
Linux Kernel:
    ip route add <prefix> encap seg6 mode encap \
        segs [SID1, SID2, ...] via <nexthop>
```

### 4.2 Linux Netlink 编码细节

```c
/* zebra/rt_netlink.c — SRv6 Headend 编码 */
if (nexthop->nh_srv6->seg6_segs && nexthop->nh_srv6->seg6_segs->num_segs) {
    nl_attr_put16(nlmsg, size, RTA_ENCAP_TYPE, LWTUNNEL_ENCAP_SEG6);

    nest = nl_attr_nest(nlmsg, size, RTA_ENCAP);
    /* 编码 SRH: struct seg6_iptunnel_encap */
    /* segments[0] = 最后一个 SID (终点), segments[N] = 第一个 SID */
    for (i = segs->num_segs - 1; i >= 0; i--)
        srh.segments[i] = segs->segs[num_segs - 1 - i];
    nl_attr_nest_end(nlmsg, nest);
}
```

### 4.3 内核效果

```bash
# MIDR 跨 Group 路由下发后的内核 FIB 效果
# 前缀 2001:db8:10::/48 通过 Group B 的 SRv6 隧道可达
ip -6 route show 2001:db8:10::/48
# 2001:db8:10::/48 encap seg6 mode encap \
#   segs [fc00:b:1::,fc00:c:1::,fc00:d:1::] \
#   via fc00:a::1 dev eth0
```

### 4.4 MIDR 中的 SRv6 封装模式

| 封装模式 | 枚举值 | 说明 | Linux 效果 |
|---------|--------|------|-----------|
| H.Insert | `SRV6_HEADEND_BEHAVIOR_H_INSERT` | 插入 SRH，原始包不变 | `mode inline` |
| **H.Encaps** | `SRV6_HEADEND_BEHAVIOR_H_ENCAPS` | 封装新 IPv6 头 + SRH | `mode encap` (默认，MIDR 使用) |

MIDR 使用 **H.Encaps** 模式，因为跨 Group 转发需要在原始 IP 包外封装新的 IPv6 头 + SRH，不修改原始报文。

---

## 五、SRv6 Local SID 模式（Group 边界节点）

Local SID 安装在 MIDR Group 边界节点上，用于终结跨 Group 隧道。

### 5.1 Local SID 行为

```c
/* lib/srv6.h — 支持的 Local SID 行为 */
enum seg6local_action_t {
    ZEBRA_SEG6_LOCAL_ACTION_END     = 1,   /* 标准 Endpoint */
    ZEBRA_SEG6_LOCAL_ACTION_END_X   = 2,   /* Endpoint with L3 cross-connect */
    ZEBRA_SEG6_LOCAL_ACTION_END_DT4 = 8,   /* Decapsulation to IPv4 table */
    ZEBRA_SEG6_LOCAL_ACTION_END_DT6 = 7,   /* Decapsulation to IPv6 table */
    ZEBRA_SEG6_LOCAL_ACTION_END_DT46 = 16, /* Decapsulation to dual table */
    ZEBRA_SEG6_LOCAL_ACTION_END_B6_ENCAP = 10, /* B6 Encaps (SR Policy) */
};
```

### 5.2 BGP-LS 学习远端 SID

```c
/* bgpd/bgp_ls_ted.c — 从 BGP-LS SRv6 SID NLRI 学到远端 SID */
int bgp_ls_originate_srv6_sid(struct bgp *bgp, ...)
{
    /* 从 TED 中的 ls_subnet.srv6[ ] 提取 SID 信息 */
    struct ls_subnet *subnet = ...;

    /* sr_subnet.sid = SID value */
    /* sr_subnet.endpoint_behavior = 行为 (End, End.X, etc.) */
    /* sr_subnet.algorithm = 算法 (0=SPF, 1=Strict SPF, etc.) */

    /* 组装 BGP-LS NLRI Type 6 并安装到 RIB */
    return bgp_ls_update(bgp, nlri, ls_attr);
}
```

### 5.3 本地 SID 安装（bgp_srv6.c）

```c
/* bgpd/bgp_srv6.c — 安装本地 SID */
void bgp_srv6_unicast_sid_endpoint(struct bgp *bgp, afi_t afi,
                                    struct interface *ifp, bool install)
{
    struct seg6local_context ctx = {};

    /* 填充 Locator 结构信息 */
    ctx.block_len = locator->block_bits_length;
    ctx.node_len = locator->node_bits_length;
    ctx.function_len = locator->function_bits_length;

    /* 选择行为: End.DT4 / End.DT6 / End.DT46 */
    act = bgp_srv6_unicast_action(bgp, afi);

    /* 通过 ZAPI 下发 */
    zclient_send_localsid(bgp_zclient, ZEBRA_ROUTE_ADD,
                          sid, IPV6_MAX_BITLEN,
                          ifp->ifindex, act, &ctx);
}
```

### 5.4 Linux Netlink 编码

```c
/* zebra/rt_netlink.c — Local SID 编码 */
/* 以 End.DT4 为例: */
case ZEBRA_SEG6_LOCAL_ACTION_END_DT4:
    nl_attr_put32(nlmsg, len, SEG6_LOCAL_ACTION, SEG6_LOCAL_ACTION_END_DT4);
    nl_attr_put32(nlmsg, len, SEG6_LOCAL_VRFTABLE, ctx->table);
    break;

/* 内核效果: */
/* ip -6 route add fc00:1::/64 encap seg6local action End.DT4 table 10 \
 *   dev sr0 */
```

---

## 六、MIDR 跨 Group SRv6 隧道完整流程

### 6.1 场景

```
 Group A (AS 65001)           Group B (AS 65002)          Group C (AS 65003)
   ┌─────────────┐             ┌─────────────┐            ┌─────────────┐
   │  R1 ─── R2  │             │  R4 ─── R5  │            │  R7         │
   │   \    /    │  fc00:ab::  │   \    /    │ fc00:bc::  │   |         │
   │    R3───────┼─────────────│────R6       │────────────│──R8         │
   │       \     │             │             │            │   |         │
   └────────┼────┘             └─────────────┘            │   R9───10.0.0.0/24│
            │                                             └─────┬───────┘
            │         SRv6 Policy Tunnel (R3 → R6 → R8 → R9)   │
            └───────────────────────────────────────────────────┘
```

### 6.2 控制平面流程

```
1. BGP-LS UPDATE (Node/Link/Prefix NLRI)
   → TED 更新 (bgp_ls_ted.c)

2. SPF 计算 (bgp_midr_spf.c)
   → 发现 10.0.0.0/24 在 Group C，跨 2 个 group 边界
   → 计算 path: R3 → R6(Group B边界) → R8(Group C边界) → R9

3. SID 列表构造 (bgp_midr_srv6.c)
   → 查询 TED 中 R6/R8/R9 发布的 SRv6 SID
   → SID List: [R6.End, R8.End, R9.End.DT4]
     • R6.End: fc00:b:1::1    (Group B 入口)
     • R8.End: fc00:c:1::1    (Group C 入口)
     • R9.End.DT4: fc00:c:2::1 (解封装到 IPv4 转发表)

4. midr_path_result 填充:
   .path_count = 1
   .paths[0].sid_count = 3
   .paths[0].sid_list = [fc00:b:1::1, fc00:c:1::1, fc00:c:2::1]
   .paths[0].nexthop = fc00:ab::6 (R6 的直连地址)
```

### 6.3 数据平面流程

```
5. midr_zebra_fill_srv6()
   → znh.seg_num = 3
   → znh.seg6_segs = [fc00:b:1::1, fc00:c:1::1, fc00:c:2::1]
   → znh.srv6_encap_behavior = SRV6_HEADEND_BEHAVIOR_H_ENCAPS
   → SET_FLAG(znh.flags, ZAPI_NEXTHOP_FLAG_SEG6)

6. zclient_route_send(ZEBRA_ROUTE_ADD, ...)

7. zebra → Netlink:

   ip -6 route add 10.0.0.0/24 \
       encap seg6 mode encap \
       segs [fc00:b:1::1, fc00:c:1::1, fc00:c:2::1] \
       via fc00:ab::6 dev eth0

8. 转发过程:
   R3: 收到去 10.0.0.0/24 的 IPv4 包
       → 封装新的 IPv6 头 + SRH [R6, R8, R9]
       → 外层 DA = R6 (fc00:ab::6)
       → 转发到 R6

   R6: 收到 SRv6 包，DA = R6.End
       → SRH SL--，DA 更新为 R8.End
       → 转发到 R8

   R8: 收到 SRv6 包，DA = R8.End
       → SRH SL--，DA 更新为 R9.End.DT4
       → 转发到 R9

   R9: 收到 SRv6 包，DA = R9.End.DT4
       → 解封装，去掉 IPv6 头 + SRH
       → 原始 IPv4 包进入 IPv4 转发表
       → 转发到 10.0.0.0/24 的出接口
```

### 6.4 各节点的配置

```bash
# ===== R3 (Group A 入口, Headend) =====
# MIDR 自动下发 SRv6 封装路由
ip -6 route add 10.0.0.0/24 \
    encap seg6 mode encap \
    segs [fc00:b:1::1, fc00:c:1::1, fc00:c:2::1] \
    via fc00:ab::6 dev eth0

# ===== R6 (Group B 边界节点) =====
# 安装 Local SID: End (继续 SRH 处理)
ip -6 route add fc00:b:1::1/128 \
    encap seg6local action End dev sr0

# ===== R8 (Group C 边界节点) =====
# 安装 Local SID: End (继续 SRH 处理)
ip -6 route add fc00:c:1::1/128 \
    encap seg6local action End dev sr0

# ===== R9 (Group C 出口节点) =====
# 安装 Local SID: End.DT4 (解封装到 IPv4 表 10)
ip -6 route add fc00:c:2::1/128 \
    encap seg6local action End.DT4 table 10 dev sr0

# R9 的 IPv4 转发表
ip route add 10.0.0.0/24 via 10.0.0.1 dev eth1 table 10
```

---

## 七、SRv6 与 MIDR 负载均衡的结合

### 7.1 多路径 SRv6

跨 Group 时可以通过多个出口实现负载均衡：

```c
/* 两个跨 Group 路径: 分别通过 R6 和 R4 */
struct midr_path_ext paths[2] = {
    {
        /* 路径 1: R3 → R6 → R8 → R9 */
        .nexthop = fc00:ab::6,
        .sid_count = 3,
        .sid_list = {fc00:b:1::1, fc00:c:1::1, fc00:c:2::1},
        .weight = 128,
        .path_owner_group = 2,
    },
    {
        /* 路径 2: R3 → R4 → R5 → R8 → R9 */
        .nexthop = fc00:ab::4,
        .sid_count = 4,
        .sid_list = {fc00:b:1::1, fc00:b:2::1, fc00:c:1::1, fc00:c:2::1},
        .weight = 127,
        .path_owner_group = 3,
    },
};

/* 内核效果: 两条 SRv6 封装路径, 按权重均衡 */
/* ip -6 route add 10.0.0.0/24
 *   nexthop encap seg6 mode encap segs [R6,R8,R9] via fc00:ab::6 weight 128
 *   nexthop encap seg6 mode encap segs [R4,R5,R8,R9] via fc00:ab::4 weight 127
 */
```

### 7.2 Per-flow 一致性

SRv6 封装 + per-flow hash 确保同一流量的所有包走同一路径：

```c
/* 内核自动基于外层 IPv6 头的 flow label + src/dst 做 hash */
/* 设置 flow label 随机化来保证均匀分布 */
znh->flags |= ZAPI_NEXTHOP_FLAG_WEIGHT;  /* 启用权重 */
/* 内核 ECMP 使用 outer IPv6 (5-tuple) hash */
```

---

## 八、SRv6 的 FRR 配置命令

### 8.1 Locator 配置

```
frr(config)# segment-routing srv6
frr(config-srv6)# locator my-locator
frr(config-srv6-loc)# prefix fc00:1::/48
frr(config-srv6-loc)# block-len 32
frr(config-srv6-loc)# node-len 16
frr(config-srv6-loc)# func-bits 16
frr(config-srv6-loc)# exit
frr(config-srv6)# exit
```

### 8.2 BGP SRv6 启用

```
frr(config)# router bgp 65001
frr(config-router)# address-family ipv6 unicast
frr(config-router-af)# segment-routing srv6
frr(config-router-af)# srv6 locator my-locator
frr(config-router-af)# srv6 unicast sid auto
frr(config-router-af)# exit-address-family
```

### 8.3 验证命令

```
frr# show segment-routing srv6 locator
frr# show segment-routing srv6 sid
frr# show ip route srv6
frr# show bgp srv6 unicast
```

---

## 九、关键代码文件索引

| 文件 | 作用 | 关键函数/结构 |
|------|------|---------------|
| `lib/srv6.h` | SRv6 基础类型定义 | `struct srv6_locator`, `enum seg6local_action_t`, SRv6 常量 |
| `lib/nexthop.h` | nexthop 中的 SRv6 | `struct nh_srv6`, `struct seg6_segs` |
| `lib/zclient.h` | ZAPI SRv6 传输 | `struct zapi_nexthop(.seg6_segs[], .seg6local_action)` |
| `lib/zclient.c` | Local SID 下发 | `zclient_send_localsid()` |
| `bgpd/bgp_srv6.c/h` | BGP SRv6 管理 | SID 分配/撤销/Announce, `bgp_srv6_unicast_ensure_afi_sid()` |
| `bgpd/bgp_srv6.h` | BGP SRv6 内联函数 | `is_srv6_unicast_enabled()`, `bgp_srv6_unicast_action()` |
| `bgpd/bgp_attr_srv6.h` | BGP 属性中的 SRv6 | `struct bgp_attr_srv6_l3service` (RFC 9252) |
| `bgpd/bgp_ls_ted.c` | BGP-LS SRv6 SID NLRI 处理 | `bgp_ls_originate_srv6_sid()` |
| `zebra/rt_netlink.c` | Kernel Netlink SRv6 编码 | `_netlink_route_build_singlepath()`, `parse_encap_seg6()` |
| **`bgpd/bgp_midr_srv6.c`** | **MIDR SRv6 隧道管理 (新增)** | `midr_srv6_install_cross_group_tunnel()` |
| **`bgpd/bgp_midr_zebra.c`** | **MIDR SRv6 路由下发 (新增)** | `midr_zebra_fill_srv6()`, `midr_zebra_fill_cross_group()` |

---

## 十、SRv6 在 MIDR 中的优势总结

| 特性 | 传统 MPLS | SRv6 in MIDR |
|------|-----------|-------------|
| **标签分发** | LDP/RSVP-TE 协议 | IPv6 路由 + BGP-LS |
| **路径编码** | 标签栈 (每个 20-bit) | SID 列表 (每个 128-bit, 可压缩 uSID) |
| **封装开销** | 需要 MPLS 支持 | 原生 IPv6 网络即支持 |
| **可编程性** | 有限 | 丰富的 Endpoint Behavior |
| **跨 Group** | 需要跨域 LSP | 原生 IPv6 可达 |
| **负载均衡** | MPLS entropy | IPv6 flow label |
| **协议依赖** | LDP/RSVP/BGP-LU | BGP-LS + IPv6 路由 |