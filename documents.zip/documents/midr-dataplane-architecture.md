# MIDR 数据平面架构总览

## 文档关系

```
documents/
├── midr-cp-dp-interface.md        ← CP→DP 接口定义（基础）
├── midr-dataplane-implementation.md ← 数据平面实现细节（基础）
└── midr-dataplane-improvements.md  ← 增强设计：策略路由+负载均衡+跨 Group（当前）
    └── midr-dataplane-architecture.md ← 本文档：架构总览（贯通三层设计）
```

三层设计层次：

| 层 | 文档 | 内容 |
|---|------|------|
| **L1: 基础接口** | `midr-cp-dp-interface.md` | CP→DP 单向通道、BASIC/ECMP/UCMP/SRv6 四种模式、统一 `midr_zebra_route_add()` 入口 |
| **L2: 实现机制** | `midr-dataplane-implementation.md` | ZAPI 构造、批量延迟聚合、Nexthop Tracking、DP 自治机制、100ms 防抖 |
| **L3: 增强设计** | `midr-dataplane-improvements.md` | 分组感知、策略路由（源路由/AS约束）、两级负载均衡、跨 Group SRv6 隧道 |

---

## 一、总体架构

```
┌─────────────────────────────────────────────────────────────────────────┐
│                        MIDR 控制平面 (bgpd)                              │
│                                                                         │
│  ┌─────────────┐  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐ │
│  │ SPF 计算     │  │ CSPF 计算    │  │ 策略引擎     │  │ 跨 Group     │ │
│  │ (group内)   │  │ (group间+TE) │  │ (源路由/AS)  │  │ 隧道管理     │ │
│  └──────┬──────┘  └──────┬───────┘  └──────┬───────┘  └──────┬───────┘ │
│         │                │                │                │          │
│         └────────────────┴────────────────┴────────────────┘          │
│                                  │                                     │
│                                  ▼                                     │
│  ┌─────────────────────────────────────────────────────────────────┐  │
│  │               midr_path_result (统一数据载体)                    │  │
│  │  • group_ctx (分组信息)  • paths[] (扩展路径)  • policy 标签     │  │
│  │  • cross_group (隧道)   • 两级权重                              │  │
│  └─────────────────────────────────────────────────────────────────┘  │
│                                  │                                     │
│                                  ▼                                     │
│  ┌─────────────────────────────────────────────────────────────────┐  │
│  │               midr_zebra_route_add() (统一入口)                   │  │
│  │  • 模式检测：BASIC | ECMP | UCMP | SRV6 | CROSS_GROUP            │  │
│  │  • 策略标签处理：tableid、steer_mode                              │  │
│  │  • 两级权重合并：group_weight × path_weight / 255                 │  │
│  │  • 批量延迟聚合：100ms window + diff                              │  │
│  └──────────────────────────┬──────────────────────────────────────┘  │
│                             │                                         │
│                             ▼ ZAPI                                     │
│                    zclient_route_send()                                │
└─────────────────────────────┬───────────────────────────────────────────┘
                              │
                              ▼
┌────────────────────────────────────────────────────────────────────────┐
│                        zebra (全部复用)                                 │
│  zapi_msg → zebra_rib → zebra_nhg → zebra_dplane → rt_netlink → FIB   │
└────────────────────────────────────────────────────────────────────────┘
```

---

## 二、数据平面处理流水线

### 2.1 路径计算到路由下发完整流程

```
          CP 计算                       DP 安装
   ──────────────────        ──────────────────────

   SPF输出原始路径                midr_zebra_route_add()
        │                               │
        ▼                               ▼
   midr_lb_compute_         midr_detect_mode_ext()
   group_weights()              │
        │                  ┌────┴────┐
        ▼                  │         │
   midr_lb_merge_          ▼         ▼
   weights()          BASIC/ECMP   SRV6/
        │              /UCMP      CROSS_GROUP
        ▼                               │
   midr_pbr_match()                     ▼
   (策略匹配 → 修改权重/路径)      填充 zapi_route
        │                          + zapi_nexthop
        ▼                               │
   midr_path_result                     ▼
   (填充完成)                   zclient_route_send()
                                    │
                                    ▼
                              Linux Kernel FIB
```

### 2.2 跨 Group 路由处理特殊流程

```
   控制平面                       数据平面
   ──────────                   ──────────
       │                            │
   BGP-LS UPDATE                   │
   (Group-Link)                    │
       │                            │
       ▼                            │
   Group SPF 计算                   │
   (受 Group ID 约束)               │
       │                            │
       ▼                            │
   检测为跨 group 路径              │
   → 分配 tunnel SID               │
   → 构造 SID List                 │
       │                            │
       ▼                            │
   midr_path_result:                │
   .group_ctx.is_cross_group=1     │
   .cross_group.tunnel_mode=SRv6   │
       │                            │
       └──────────────┬─────────────┘
                      │
                      ▼
            midr_zebra_fill_cross_group()
            → 填充 nexthop + SRv6 encap
            → 设置 tableid (group 专属路由表)
            → 安装 PBR rule (源路由时)
                      │
                      ▼
              zclient_route_send()
```

---

## 三、模块依赖关系

```
                        ┌───────────────────┐
                        │  bgp_zclient       │
                        │  (全局单例，复用)   │
                        └────────┬──────────┘
                                 │
                ┌────────────────┼────────────────┐
                │                │                │
                ▼                ▼                ▼
        ┌──────────────┐ ┌──────────────┐ ┌──────────────┐
        │midr_zebra    │ │midr_pbr     │ │midr_srv6    │
        │(路由下发核心)  │ │(策略路由)    │ │(SRv6 隧道)   │
        └──────┬───────┘ └──────┬───────┘ └──────┬───────┘
               │                │                │
               ▼                ▼                ▼
        ┌──────────────┐ ┌──────────────┐ ┌──────────────┐
        │midr_lb      │ │midr_nht     │ │midr_cross_   │
        │(负载均衡)    │ │(NH tracking) │ │group(跨group) │
        └──────────────┘ └──────────────┘ └──────────────┘
               │
               ▼
        ┌──────────────┐
        │midr_vty     │
        │(CLI/监控)    │
        └──────────────┘
```

---

## 四、关键数据流

### 4.1 普通（Group 内）路由

```
CP: SPF → midr_path_result(.group_ctx.group_id=0)
DP: midr_detect_mode() → BASIC/ECMP/UCMP
    → zapi_route(.tableid=0) → zebra → FIB
```

### 4.2 跨 Group 路由

```
CP: Group-SPF → midr_path_result(.group_ctx.group_id=X, .is_cross_group=1)
    → SID List 构造
DP: midr_detect_mode() → CROSS_GROUP
    → zapi_route(.tableid=MIDR_TABLE+X, .nexthop.seg6_segs[ ])
    → zebra → FIB (SRv6 encap)
```

### 4.3 策略路由（源路由）

```
CP: midr_pbr_match(src_prefix, dst_prefix) → match entry ID=10
    → 设置 steer_mode=1, policy_id=10, target_group=3
DP: midr_zebra_route_add()
    → zapi_pbr_rule_encode() 安装 PBR rule
    → 安装路由到 table MIDR_PBR_TABLE+3
    → 流量匹配 src_prefix → 查 table 3 → 走指定 group
```

### 4.4 负载均衡

```
CP: midr_lb_compute_group_weights(algo=bandwidth)
    → Group A: 200Mbps → weight=170
    → Group B: 100Mbps → weight=85
    midr_lb_merge_weights()
    → Path A1: final_weight = 170 * 128 / 255 = 85
    → Path A2: final_weight = 170 * 127 / 255 = 84
    → Path B1: final_weight = 85 * 255 / 255 = 85
DP: zapi_nexthop[0].weight=85, zapi_nexthop[1].weight=84, zapi_nexthop[2].weight=85
    → zebra_nhg → Kernel nexthop group weight
```

---

## 五、FRR 代码集成点

| 集成点 | 文件 | 修改方式 | 说明 |
|--------|------|---------|------|
| ZAPI 通信 | `lib/zclient.c/h` | 复用 | 不变 |
| ZAPI nexthop 编码 | `lib/zclient.h` (`struct zapi_nexthop`) | 复用 | 原生支持 weight、seg6_segs、srte_color |
| PBR 框架 | `lib/pbr.h` | 复用 | 原生支持 source/dst rule |
| SRv6 框架 | `lib/srv6.h` | 复用 | 原生支持 SRH 封装 |
| Nexthop Group | `zebra/zebra_nhg.c` | 复用 | 原生支持 weight |
| NH Tracking hook | `bgpd/bgp_nht.c` | 1 行 hook | 在 `bgp_nexthop_update()` 末尾调用 |
| BGP-LS TED | `bgpd/bgp_ls_ted.c/h` | 复用/扩展 | MIDR 使用 TED 作为拓扑源 |
| 已有 SPF | `bgpd/bgp_midr.c/h` | 扩展 | MIDR 在其上增加 group 感知 |
| 已有 zebra 出口 | `bgpd/bgp_midr_zebra.c/h` | 参考但独立 | MIDR 有独立的 `bgp_midr_zebra.c` |

---

## 六、性能评估

### 6.1 路径计算复杂度

| 操作 | 复杂度 | 说明 |
|------|--------|------|
| Group 内 SPF | O((N_g + E_g) log N_g) | N_g = group 内节点数，E_g = group 内边数 |
| Group 间 SPF | O((N_g + E_g) log N_g) | N_g = group 数，E_g = group 间边数 |
| 策略匹配 | O(P) | P = 策略条目数，hash-based |
| 两级权重计算 | O(N_p × N_g) | N_p = 总路径数，N_g = group 数 |
| ZAPI 编码 | O(N_p) | N_p = nexthop 数 |

### 6.2 内存开销

| 对象 | 大小 | 说明 |
|------|------|------|
| `midr_path_ext` | ~200 bytes | 含 avoid_as flex array |
| `midr_path_result` | ~64 bytes + paths | 轻量包装 |
| `midr_policy_entry` | ~256 bytes | 含 AS 列表 |
| `midr_cross_group_tunnel` | ~512 bytes | 含 SID 列表和保护路径 |

### 6.3 批量更新性能

| 场景 | 100ms 窗口 | 聚合率 | 下发次数减少 |
|------|-----------|--------|------------|
| 正常拓扑抖动 | 10次→1次 | 10:1 | 90% |
| 链路 flapping | 100次→1次 | 100:1 | 99% |
| 收敛稳定 | 1次→1次 | 1:1 | 0% |

---

## 七、部署模型

### 7.1 典型部署拓扑

```
         Group 1 (AS 65001)          Group 2 (AS 65002)
    ┌─────────────────────┐    ┌─────────────────────┐
    │                     │    │                     │
    │  R1 ─── R2          │    │          R4 ─── R5  │
    │   \    /            │    │          /          │
    │    R3               │    │         R6          │
    │       \             │    │        /            │
    └────────┼────────────┘    └───────┼─────────────┘
             │                        │
             │       Group Link       │
             └────────────────────────┘

    Group 内: 标准 BGP-LS SPF (IGP style)
    Group 间: 传递 group-link state, 使用 SRv6 隧道封装
    策略: Group 1 → Group 2 流量可通过 Policy 10 指定走 R3-R6 路径
```

### 7.2 路由表组织

```
Linux Kernel Routing Tables:

Table main (254):         MIDR default routes
Table 10001:              MIDR Group 1 路由
Table 10002:              MIDR Group 2 路由
Table 20001:              MIDR PBR Group 1 (源路由)
Table 20002:              MIDR PBR Group 2 (源路由)
```

### 7.3 PBR 规则

```
# ip rule show
0:      from all lookup local
10000:  from 2001:db8:1::/48 to 2001:db8:2::/48 lookup 20001  ← MIDR Policy 10
10001:  from 2001:db8:3::/48 to 2001:db8:4::/48 lookup 20002  ← MIDR Policy 20
32766:  from all lookup main
32767:  from all lookup default
```

---

## 八、未来扩展

| 方向 | 说明 | 优先级 |
|------|------|--------|
| **动态 Group 发现** | BGP-LS 自动发现并协商 Group 划分 | P2 |
| **自适应 LB** | 基于实时链路利用率动态调整权重 | P2 |
| **AI 驱动策略** | 基于历史延迟/带宽 AI 模型优化策略 | P3 |
| **SRv6 uSID 压缩** | 支持 uSID 压缩格式以减少 SID 栈开销 | P2 |
| **多拓扑实例** | 支持多拓扑（MT）隔离的 Group | P3 |
| **Segment Routing Policy** | 完整 SR Policy 框架集成 | P2 |
| **TI-LFA 保护** | 跨 Group 的快速重路由保护 | P3 |