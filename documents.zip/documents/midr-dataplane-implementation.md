# MIDR 数据平面实现

## 一、设计目标

将控制平面的计算结果快速、原子、稳定地安装到 Linux 内核 FIB。

| 目标 | 说明 |
|------|------|
| **快速下发** | 同进程函数调用 + ZAPI，端到端 < 10ms |
| **原子更新** | 批量 diff 后一次性下发，避免"部分安装"导致瞬态黑洞 |
| **防抖聚合** | 100ms 窗口聚合频繁拓扑抖动，减少内核 FIB 更新次数 |
| **双模式支持** | 同一接口支持纯 IP（BASIC/ECMP/UCMP）和 SRv6 严格路径两种内核路由格式 |

---

## 二、架构概述

```
┌─────────────────────────────────────────────────────────────────┐
│  bgpd                                                           │
│                                                                 │
│  ┌──────────────────┐     ┌────────────────────┐                │
│  │SPF/CSPF 计算     │────►│ bgp_midr_zebra.c   │                │
│  │ (其他成员负责)   │     │ - 接收结果         │                │
│  │                  │     │ - 识别模式         │                │
│  └──────────────────┘     │ - 填充 zapi        │                │
│                           │ - 批量更新         │                │
│                           └──────────┬─────────┘                │
│                                      │                          │
│                           ┌────────────────────┐                │
│                           │ lib/zclient.c      │                │
│                           │ - 序列化 zapi      │                │
│                           └────────────────────┘                │
│                                      │                          │
│                                      ▼ ZAPI                     │
│                                                                 │
│                                                                 │
│  ┌────────────────────┐                                         │
│  │ bgp_midr_nht.c     │                                         │
│  │ - 批量注册/追踪    │                                         │
│  └────────────────────┘                                         │
│        ← DP 自治：注册/注销 NH (安装/撤销时触发)                 │
└─────────────────────────────────────────────────────────────────┘
                                     │
                                     │ ZAPI (Unix Domain Socket)
                                     ▼
┌─────────────────────────────────────────────────────────────────┐
│  zebra (全部复用，不修改)                                        │
│  zebra/zapi_msg.c → zebra/zebra_rib.c → zebra/zebra_nhg.c       │
│  → zebra/zebra_dplane.c → zebra/rt_netlink.c → Kernel FIB       │
└─────────────────────────────────────────────────────────────────┘
```

---

## 三、文件组织与代码边界

### 3.1 为什么不复用 `bgp_zebra.c`

`bgp_zebra.c`（~5000 行）的**全部函数深度绑定 `struct bgp_path_info`**——即传统 BGP 路由（从 BGP UPDATE 学来的 NLRI + Path Attribute）。

| 对比项 | `bgp_zebra.c` | MIDR 需求 |
|--------|---------------|-----------|
| **输入数据结构** | `bgp_path_info`（含 peer、AS_PATH、MED、Community） | `midr_path_result`（含 nexthop、weight、sid_list[]） |
| **Nexthop 来源** | `bgp_path_info_mpath_next()` 链 | `result->paths[]` 数组 |
| **SRv6 支持** | 单段 SID（`seg_num = 1`，VPN/L3Service） | 多段 Segment List（`seg_num = N`，严格路径） |
| **ECMP weight** | 从 Extended Community 提取 link-bandwidth | 直接用 `result->paths[i].weight` |
| **发送模型** | 逐条路由即时发送 | 100ms batch deferred + diff |
| **MPLS/EVPN** | 处理 label 栈、RMAC、VNI | 不需要 |

两者**数据结构完全不兼容**，硬塞进 `bgp_zebra.c` 等于在同一个函数里维护两条独立的数据转换路径，维护性和稳定性都会急剧恶化。

### 3.2 职责分工

```
┌─────────────────────────────────────────────────────────────────┐
│  bgpd                                                           │
│                                                                 │
│  ┌──────────────────┐        ┌──────────────────────────────┐   │
│  │  bgp_zebra.c     │        │  bgp_midr_zebra.c (新建)     │   │
│  │  ─────────────── │        │  ─────────────────────────   │   │
│  │  传统 BGP 路由   │        │  MIDR 路由 (SPF 结果)        │   │
│  │  • unicast/vpn   │        │  • BASIC / ECMP / UCMP / SRV6│   │
│  │  • evpn          │        │  • batch deferred update     │   │
│  │  • redistribute  │        │  • mode detection            │   │
│  │  • mpls label    │        │                              │   │
│  └──────────┬───────┘        └──────────────┬───────────────┘   │
│             │                               │                   │
│             │                               │                   │
│             ▼                               ▼                   │
│  ┌───────────────────────────────────────────────────────────┐  │
│  │              共用 bgp_zclient (全局单例)                  │  │
│  │              zclient_route_send()                         │  │
│  └───────────────────────────────────────────────────────────┘  │
│                                                                 │
│  ┌──────────────────┐        ┌──────────────────────────────┐   │
│  │  bgp_nht.c       │        │  bgp_midr_nht.c (新建)       │   │
│  │  ─────────────── │        │  ─────────────────────────   │   │
│  │  传统 BGP NHT    │        │  MIDR NHT                    │   │
│  │  • bnc 结构      │◄───────│ • midr_route_entry 结构      │   │
│  │  • bgp_process() │  hook  │ • 只 withdraw/reinstall      │   │
│  └──────────┬───────┘        │ • 绝不触发 SPF/修改 LSDB     │   │
│                              └──────────────┬───────────────┘   │
└─────────────────────────────────────────────────────────────────┘
```

**唯一的耦合点**：`bgp_nht.c` 的 `bgp_nexthop_update()` 末尾调用 `midr_nht_nexthop_update()`（1 行 hook）。

### 3.3 使用 `bgp_zclient` 全局变量

FRR 中一个 daemon 只有一个 `zclient` 实例。`bgp_midr_zebra.c` 直接复用 `bgp_zclient` 发送 ZAPI 消息，无需、也不能创建独立 zclient：

```c
/* bgp_midr_zebra.c */
extern struct zclient *bgp_zclient;

/* 发送路由 */
zclient_route_send(ZEBRA_ROUTE_ADD, bgp_zclient, &api);

/* 注册 NH tracking */
zclient_send_nexthop_reg(bgp_zclient, ...);
```

---

## 四、封装类型与模式识别

### 4.1 四种数据平面模式

数据平面根据 `midr_path_result` 字段自动判断：

```c
/* bgpd/bgp_midr_zebra.c */

enum midr_mode {
    MIDR_MODE_BASIC,        /* 单路径 */
    MIDR_MODE_ECMP,         /* 等权重多路径 */
    MIDR_MODE_UCMP,         /* 加权多路径 */
    MIDR_MODE_SRV6,         /* SRv6 严格路径 */
};

enum midr_mode midr_detect_mode(struct midr_path_result *result)
{
    if (result->explicit.sid_count > 0)
        return MIDR_MODE_SRV6;
    if (result->path_count > 1 && result->paths[0].weight > 0)
        return MIDR_MODE_UCMP;
    if (result->path_count > 1)
        return MIDR_MODE_ECMP;
    return MIDR_MODE_BASIC;
}
```

| 模式 | 触发条件 | 内核效果 |
|------|---------|---------|
| **BASIC** | `path_count = 1, sid_count = 0` | 标准单路径路由 |
| **ECMP** | `path_count > 1, weight = 0, sid_count = 0` | 等权重多路径（内核自动均衡） |
| **UCMP** | `path_count > 1, weight > 0, sid_count = 0` | 加权多路径（`ip nexthop show`） |
| **SRV6** | `sid_count > 0` | SRv6 封装路由（`ip -6 route show \| grep seg6`） |

### 4.2 统一入口函数

```c
/* 控制平面唯一调用入口 */
void midr_zebra_route_add(struct bgp *bgp,
                                struct prefix *p,
                                struct midr_path_result *result);

/* 内部实现 */
void midr_zebra_route_add(struct bgp *bgp, struct prefix *p,
                                struct midr_path_result *result)
{
    struct zapi_route api = {};

    zapi_route_init(&api);
    api.type = ZEBRA_ROUTE_BGP;
    api.safi = SAFI_UNICAST;
    api.vrf_id = bgp->vrf_id;
    api.prefix = *p;
    api.tableid = 0;                    /* 所有模式固定主表（v2.1 不区分 VRF） */
    SET_FLAG(api.flags, ZEBRA_FLAG_ALLOW_RECURSION);

    switch (midr_detect_mode(result)) {
    case MIDR_MODE_BASIC:
        midr_zebra_fill_basic(&api, result);
        break;
    case MIDR_MODE_ECMP:
        midr_zebra_fill_ecmp(&api, result);
        break;
    case MIDR_MODE_UCMP:
        midr_zebra_fill_ucmp(&api, result);
        break;
    case MIDR_MODE_SRV6:
        midr_zebra_fill_srv6(&api, result);
        break;
    }

    SET_FLAG(api.message, ZAPI_MESSAGE_NEXTHOP);
    zclient_route_send(ZEBRA_ROUTE_ADD, bgp->zclient, &api);
}
```

---

## 五、各模式填充实现

### 5.1 BASIC 模式（单路径纯 IP）

```c
static void midr_zebra_fill_basic(struct zapi_route *api,
                                   struct midr_path_result *result)
{
    struct zapi_nexthop *znh = &api->nexthops[0];

    api->nexthop_num = 1;
    znh->gate = result->paths[0].nexthop;
    znh->type = NEXTHOP_TYPE_IPV6;
    znh->weight = 0;                    /* 单路径无权重 */
    znh->seg_num = 0;                   /* 无 SRH */
}
```

**内核效果**:
```bash
ip route add 10.0.0.0/24 via 2001:db8:a::1
```
> 注：nexthop 为全局 IPv6 地址时，内核自动解析出接口，无需 `dev eth0`。若使用 link-local 地址（如 `fe80::1`），则需显式指定 `dev <ifname>`。

### 5.2 ECMP 模式（等权重多路径）

```c
static void midr_zebra_fill_ecmp(struct zapi_route *api,
                                  struct midr_path_result *result)
{
    for (int i = 0; i < result->path_count && i < MULTIPATH_NUM; i++) {
        struct zapi_nexthop *znh = &api->nexthops[i];

        znh->gate = result->paths[i].nexthop;
        znh->type = NEXTHOP_TYPE_IPV6;
        znh->weight = 0;                    /* 等权重，不设置 weight flag */
        znh->seg_num = 0;
    }
    api->nexthop_num = result->path_count;
}
```

**内核效果**:
```bash
ip route add 10.0.0.0/24 \
    nexthop via 2001:db8:a::1 \
    nexthop via 2001:db8:b::1 \
    nexthop via 2001:db8:c::1
```

> 与 UCMP 的区别：ECMP 不设置 `ZAPI_NEXTHOP_FLAG_WEIGHT`，内核自动做等权重均衡。

### 5.3 UCMP 模式（加权多路径）

```c
static void midr_zebra_fill_ucmp(struct zapi_route *api,
                                  struct midr_path_result *result)
{
    for (int i = 0; i < result->path_count && i < MULTIPATH_NUM; i++) {
        struct zapi_nexthop *znh = &api->nexthops[i];

        znh->gate = result->paths[i].nexthop;
        znh->type = NEXTHOP_TYPE_IPV6;
        znh->weight = result->paths[i].weight;
        SET_FLAG(znh->flags, ZAPI_NEXTHOP_FLAG_WEIGHT);
        znh->seg_num = 0;
    }
    api->nexthop_num = result->path_count;
    SET_FLAG(api->flags, ZEBRA_FLAG_USE_RECURSIVE_WEIGHT);
}
```

**内核效果**:
```bash
ip route add 10.0.0.0/24 \
    nexthop via 2001:db8:a::1 weight 204 \
    nexthop via 2001:db8:b::1 weight 51

ip nexthop show
# id 42 group 204,51
```

### 5.4 SRv6 模式（严格路径）

```c
static void midr_zebra_fill_srv6(struct zapi_route *api,
                                  struct midr_path_result *result)
{
    struct zapi_nexthop *znh = &api->nexthops[0];

    api->nexthop_num = 1;
    znh->gate = result->paths[0].nexthop;
    znh->type = NEXTHOP_TYPE_IPV6;
    znh->weight = 0;

    /* SRv6 SID 列表 */
    znh->seg_num = result->explicit.sid_count;
    for (int j = 0; j < znh->seg_num && j < SRV6_MAX_SEGS; j++)
        znh->seg6_segs[j] = result->explicit.sid_list[j];

    znh->srv6_encap_behavior = SRV6_HEADEND_BEHAVIOR_H_ENCAPS;
    SET_FLAG(znh->flags, ZAPI_NEXTHOP_FLAG_SEG6);
}
```

**内核效果**:
```bash
ip -6 route add 10.1.0.0/16 \
    encap seg6 mode inline \
    segs [2001:db8:1::1,2001:db8:2::1,2001:db8:3::1] \
    via 2001:db8:a::1
```

---

## 六、批量更新与延迟聚合

### 6.1 为什么需要延迟聚合

拓扑频繁抖动时（如链路状态快速 up/down），如果每次变化都立即下发，会导致：
- 内核 FIB 频繁更新，CPU 飙高
- 部分安装导致瞬态黑洞
- 路由震荡

### 6.2 实现机制

```c
/* bgpd/bgp_midr_zebra.c */

struct midr_zebra_pending {
    struct hash *adds;          /* 待安装的前缀集合 */
    struct hash *dels;          /* 待删除的前缀集合 */
    struct event *t_update;     /* 延迟定时器 */
};

/* 控制平面检测到拓扑变化时调用 */
void midr_zebra_route_update_deferred(struct bgp *bgp)
{
    /* 如果已有定时器在跑，不做任何事（自然合并到同一次批量） */
    if (pending.t_update)
        return;

    /* 启动 100ms 延迟定时器 */
    event_add_timer(bgp->master, midr_zebra_do_batch_update, bgp, 0.1, &pending.t_update);
}

/* 定时器回调：执行批量差集更新 */
static void midr_zebra_do_batch_update(struct event *event)
{
    /* 1. 撤销 dels 中的前缀 */
    hash_iterate(pending.dels, midr_zebra_send_del, NULL);

    /* 2. 安装 adds 中的前缀 */
    hash_iterate(pending.adds, midr_zebra_send_add, NULL);

    /* 3. 清理状态 */
    hash_clean(pending.dels, NULL);
    hash_clean(pending.adds, NULL);
    pending.t_update = NULL;
}
```

### 6.3 立即 flush（紧急场景）

严重故障（如本地出接口 down）时，不等待 100ms，立即下发 pending 中的变更：

```c
/* 紧急撤销：接口 down，单路径 SRv6 需立即删除 */
midr_zebra_route_del(bgp, prefix);        /* 暂存到 pending.dels */
midr_zebra_route_flush(bgp);              /* 立即 flush，跳过 100ms 等待 */
```

`flush()` 与 `deferred()` 的区别：

| 函数 | 延迟 | 使用场景 |
|------|------|---------|
| `midr_zebra_route_update_deferred()` | 100ms | 正常拓扑变化，聚合批量下发 |
| `midr_zebra_route_flush()` | 0ms | 紧急故障，立即生效 |

**注意**：`add()`/`del()` 本身**从不立即下发**，必须通过 `deferred()` 或 `flush()` 触发。

### 6.4 Batch 容量上限

`pending.adds` + `pending.dels` 超过 `MIDR_BATCH_MAX`（默认 1000）时，自动触发 flush，不等 100ms 定时器到期。防止单次 ZAPI 消息过大。

---

## 七、Nexthop Tracking

### 7.1 职责

NHT 是**数据平面内部自治机制**，不向上回调控制平面：

- 路由安装时：批量注册 nexthop 追踪
- 路由撤销时：批量注销 nexthop 追踪
- zebra 通知可达性变化时：**DP 自治处理**（withdraw / 无操作），绝不触发 SPF 重算

### 7.2 接口

```c
/* bgpd/bgp_midr_nht.h */

void midr_nht_register_bulk(struct bgp *bgp, struct midr_route_entry *entry);
void midr_nht_unregister_bulk(struct bgp *bgp, struct midr_route_entry *entry);
void midr_nht_nexthop_update(struct zapi_route *nhr);
```

### 7.3 通知流程（DP 自治）

```
zebra/zebra_rnh.c 检测到 nexthop 不可达
        │
        ▼ ZAPI_NEXTHOP_UPDATE
lib/zclient.c 解码消息
        │
        ▼ 回调
bgp_midr_nht.c: midr_nht_nexthop_update()
        │
        ├── 多路径 (ECMP/UCMP):
        │   └── 无操作
        │       内核自动从 NHG 移除 dead nexthop
        │
        └── 单路径 (BASIC/SRV6):
            └── midr_zebra_route_del() 撤销该路由
        │
        ▼
【不回调 CP，不修改 LSDB，不触发 SPF】
```

| 路由模式 | NH Down 时的 DP 行为 |
|---------|---------------------|
| **ECMP/UCMP** | 无操作。内核从 NHG 自动剔除 dead nexthop，流量继续从剩余路径转发 |
| **BASIC (单路径)** | 撤销路由。等 LSDB 更新后 CP 自然重算并重新下发 |
| **SRv6 (单路径)** | 撤销路由。SRv6 严格路径无本地备份，流量丢弃直到 CP 重算 |

### 7.4 为什么 NHT 不触发 SPF 重算

| 事件来源 | 处理层级 | 行为 | 原因 |
|---------|---------|------|------|
| **Local NH down** | DP 自治 | withdraw 受影响路由 | LSDB 未变，SPF 重算结果不变 |
| **BGP-LS UPDATE** | CP 处理 | 更新 LSDB → 触发 SPF 重算 → 重新下发 | 真正的拓扑变化 |

Local NH failure 是**本地转发面问题**（出接口 down、直连邻居不可达），不是**全网拓扑变化**。LSDB 只在收到 BGP-LS UPDATE 时更新，CP 只在 LSDB 变化时重算。

---

## 八、与 zebra 的交互

### 8.1 ZAPI 消息

| 方向 | 消息类型 | 内容 | 说明 |
|------|---------|------|------|
| bgpd → zebra | `ZEBRA_ROUTE_ADD` | `zapi_route`（含 `nexthops[]`、`weight`、`seg6_segs`） | 安装/更新路由 |
| bgpd → zebra | `ZEBRA_ROUTE_DELETE` | `zapi_route`（前缀） | 撤销路由 |
| bgpd → zebra | `ZEBRA_NEXTHOP_REGISTER` | nexthop 前缀列表 | 注册 NH 追踪 |
| zebra → bgpd | `ZEBRA_NEXTHOP_UPDATE` | `zapi_route`（nexthop 可达性变化） | DP 自治处理：ECMP/UCMP 无操作，单路径 withdraw |

### 8.2 zebra 处理链路（全部复用）

```
zebra/zapi_msg.c          ← 接收 ZAPI 消息，解析 zapi_route
    │
    ▼
zebra/zebra_rib.c         ← RIB 决策，管理路由条目
    │
    ▼
zebra/zebra_rnh.c         ← Nexthop 递归解析
    │
    ▼
zebra/zebra_nhg.c         ← NHG（Nexthop Group）管理，处理 weight
    │
    ▼
zebra/zebra_dplane.c      ← 异步 Dataplane 队列
    │
    ▼
zebra/rt_netlink.c        ← Netlink 编码下发
    │
    ▼
Linux Kernel FIB          ← 最终生效
```

**无需修改 zebra 任何代码**。FRR 原生支持：
- `zapi_nexthop.weight`（UCMP）
- `zapi_nexthop.seg6_segs[]`（SRv6）
- `zapi_nexthop.srv6_encap_behavior`（SRv6 封装模式）

---

## 九、文件清单

| 优先级 | 新增文件 | 说明 |
|--------|---------|------|
| P0 | `bgpd/bgp_midr_zebra.c/h` | 封装选择、ZAPI 构造、批量更新、延迟聚合 |
| P0 | `bgpd/bgp_midr_nht.c/h` | Nexthop Tracking 批量封装 |
| P1 | `bgpd/bgp_midr_vty.c/h` | CLI/调试（`show midr route`、`show midr pending`） |

**复用文件（不修改）**:
- `lib/zclient.c/h` — ZAPI 通信
- `zebra/zapi_msg.c` — ZAPI 消息接收
- `zebra/zebra_rib.c` — RIB 决策
- `zebra/zebra_rnh.c` — RNH 递归解析
- `zebra/zebra_nhg.c` — NHG 管理
- `zebra/zebra_dplane.c` — 异步 Dataplane
- `zebra/rt_netlink.c` — Netlink 编码下发

**现有文件（最小修改，仅 1 行 hook）**:
- `bgpd/bgp_nht.c` — 在 `bgp_nexthop_update()` 末尾调用 `midr_nht_nexthop_update()`


