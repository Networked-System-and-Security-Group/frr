# MIDR 数据平面改进设计

## 概述

本文档在已有 `midr-cp-dp-interface.md` 和 `midr-dataplane-implementation.md` 的基础上，针对 MIDR（Multi-Connection Domain Routing，多连接域间路由）的数据平面进行增强设计。MIDR 的核心思想是：先将 BGP 路由器分组，group 内和 group 间都使用链路状态 BGP（BGP-LS + SPF），但 group 间传递的是压缩后的 group 链路信息（Group-Link State）。

**核心改进方向**：

| 方向 | 现状（RFC 9815） | MIDR 改进 |
|------|----------------|-----------|
| **分组感知** | 无分组概念，全局 SPF | 带 Group-ID 的分层 SPF，group 内/间路由差异处理 |
| **路由下发** | `bgp_midr_route` 只含 nexthop + metric | 扩展支持 group-label、跨 group 隧道封装、SID 栈 |
| **策略路由** | 无策略引擎 | 源路由（Source-based Steering）、AS-path 过滤、Color/Group 联合约束 |
| **负载均衡** | ECMP/UCMP 仅基于 weight | group 级+path 级两级 ECMP/UCMP，跨 group 流量调谐 |
| **T E** | 无 | 加入 TE 度量（delay、jitter、loss、affinity）到路径选择和权重计算 |

---

## 一、分组感知的数据结构扩展

### 1.1 核心数据结构

```c
/* bgpd/bgp_midr_zebra.h — 增强版 */

#define MIDR_GROUP_ID_MAX   255
#define MIDR_MAX_PATHS      64
#define MIDR_PATH_WEIGHT_MAX 255

/* Group 级信息 */
struct midr_group_info {
    uint8_t     group_id;           /* 本地 group ID (0=不分组/全局) */
    uint8_t     is_cross_group;     /* 1=跨 group 路径, 0=group 内路径 */
    uint32_t    group_metric;       /* group 级聚合度量 */
    uint32_t    group_te_metric;    /* group 级 TE 度量 (delay/us) */
};

/* 单条 route 的路径信息 — 增强版 */
struct midr_path_ext {
    union g_addr       nexthop;           /* 物理/隧道下一跳地址 */
    uint32_t           ifindex;           /* 本地出接口 (0=由 zebra 解析) */

    /* ---- 度量 ---- */
    uint32_t           metric;            /* IGP 度量 */
    uint32_t           te_metric;         /* TE 度量 (delay/us) */
    float              avail_bw;          /* 瓶颈可用带宽 (Mbps) */
    float              max_bw;            /* 最大链路带宽 (Mbps) */

    /* ---- 分组 ---- */
    uint8_t            path_owner_group;  /* 该路径所属的 group ID */
    uint8_t            is_cross_group;    /* 跨 group 标志 */
    struct in6_addr    tunnel_sid;        /* 跨 group 隧道封装的 SID (SRv6) */
    uint8_t            tunnel_sid_count;  /* 隧道 SID 数 (0=无隧道) */

    /* ---- 策略约束 ---- */
    uint8_t            weight;            /* UCMP 权重 (1-255, 0=ECMP) */
    uint32_t           color;            /* SR-TE Color */
    uint32_t           affinity;          /* 链路亲和力位图 */
    uint8_t            avoid_as[];        /* 避免经过的 AS-path (flexible) */

    /* ---- SRv6 ---- */
    struct in6_addr    sid_list[SRV6_MAX_SEGS];
    uint8_t            sid_count;         /* 0=纯IP, >0=SRv6 */
};

/* 计算结果（CP → DP 唯一数据载体）— 增强版 */
struct midr_path_result {
    /* ---- 分组上下文 ---- */
    struct midr_group_info group_ctx;

    /* ---- 路径数组 ---- */
    struct midr_path_ext   *paths;
    uint8_t                path_count;

    /* ---- 跨 group 隧道信息 ---- */
    struct {
        struct in6_addr    ingress_sid;    /* 入口 group 的 SID */
        struct in6_addr    egress_sid;     /* 出口 group 的 SID */
        uint8_t            tunnel_mode;    /* 0=直连, 1=SRv6 Policy, 2=GRE */
    } cross_group;

    /* ---- 策略标签 ---- */
    uint32_t               policy_id;      /* 匹配的策略条目 ID (0=无) */
    uint8_t                steer_mode;     /* 0=目的路由, 1=源路由, 2=服务链 */
};
```

### 1.2 零值语义增强

| 字段 | 零值 | 非零 |
|------|------|------|
| `group_ctx.group_id` | `0` | 本地 group ID |
| `group_ctx.is_cross_group` | group 内 | `1` = 跨 group |
| `path_ext.is_cross_group` | group 内路径 | 跨 group 路径 |
| `path_ext.tunnel_sid_count` | 无隧道封装 | 跨 group 使用隧道 |
| `path_ext.color` | 无 Color 约束 | 按 Color 策略选路 |
| `path_ext.steer_mode` | 目的路由 | 源路由/服务链 |

---

## 二、策略路由子系统

### 2.1 设计目标

MIDR 策略路由支持三大类策略：

| 策略类型 | 匹配条件 | 动作 | 典型场景 |
|---------|---------|------|---------|
| **源路由 (Source Routing)** | 源前缀 + 目的前缀 + Group | 强制走指定 group/nexthop | 多出口分流、租户隔离 |
| **AS-path 约束 (AS Constraint)** | 避免/要求经过特定 AS | 排除/优选特定路径 | 合规性需求、避免特定 AS |
| **Color/Group 联合策略** | Color + Group-ID | 映射到特定 TE 隧道 | 低延迟/高带宽需求 |

### 2.2 策略表

```c
/* bgpd/bgp_midr_pbr.h — 新增 */

/* MIDR 策略条目 */
struct midr_policy_entry {
    uint32_t        id;             /* 全局唯一策略 ID */
    uint32_t        priority;       /* 优先级 (数值越小越优先) */
    uint8_t         installed;      /* 是否已安装到数据平面 */

    /* ---- 匹配条件 ---- */
    struct {
        struct prefix src_prefix;   /* 源前缀 (AF_INET/AF_INET6) */
        struct prefix dst_prefix;   /* 目的前缀 */
        uint8_t       src_group_id; /* 源 Group ID (0=任意) */
        uint8_t       dst_group_id; /* 目的 Group ID (0=任意) */
        uint32_t      color;        /* SR-TE Color (0=任意) */
        uint32_t      as_path_avoid;/* 避免的 AS 序号 (AS_PATH segment index) */
        as_t          as_avoid[];   /* 避免的 AS 列表 */
    } match;

    /* ---- 动作 ---- */
    struct {
        uint8_t       action;       /* 0=选路, 1=丢弃, 2=重定向 */
        uint8_t       target_group; /* 重定向到目标 Group */
        uint32_t      target_color; /* 强制使用某 Color 的路径 */
        uint8_t       lb_algo;      /* 0=ECMP, 1=UCMP, 2=per-flow */
    } action;

    /* ---- 统计 ---- */
    uint64_t        matched_pkts;
    uint64_t        matched_bytes;
};
```

### 2.3 策略匹配引擎

```
                        ┌─────────────────────────┐
                        │   IP Packet In           │
                        └──────────┬──────────────┘
                                   │
                                   ▼
                        ┌─────────────────────────┐
                        │  1. 查找 midr_policy     │
                        │     entries by priority  │
                        │     (hash on src/dst)    │
                        └──────────┬──────────────┘
                                   │
                    ┌──────────────┴──────────────┐
                    │                              │
                    ▼                              ▼
        ┌──────────────────┐          ┌──────────────────────┐
        │ 2a. 匹配成功     │          │ 2b. 无匹配           │
        │     ↓            │          │     ↓                 │
        │ 执行策略动作     │          │ 回退到目的路由        │
        │ • 指定 group     │          │ (默认 SPF 结果)       │
        │ • 指定 color     │          │                       │
        │ • 排除路径       │          │                       │
        └────────┬─────────┘          └──────────┬───────────┘
                 │                               │
                 ▼                               ▼
        ┌───────────────────────────────────────────────┐
        │  3. 构造 midr_path_result (含策略标签)         │
        │     ↓                                         │
        │  midr_zebra_route_add() 下发                   │
        └───────────────────────────────────────────────┘
```

### 2.4 源路由实现（基于 Linux PBR 框架）

MIDR 利用 Linux PBR 框架实现源路由，不需要修改 zebra：

```c
/* bgpd/bgp_midr_pbr.c — 源路由实现 */

/* 创建基于源地址的策略路由规则 */
static int midr_pbr_install_source_rule(struct midr_policy_entry *entry,
                                         struct pbr_rule *rule)
{
    /* 使用 FRR 已有的 PBR 框架 (lib/pbr.h) */
    rule->vrf_id = VRF_DEFAULT;
    rule->family = AF_INET6;
    rule->priority = entry->priority;
    rule->unique = entry->id;

    /* 填充匹配条件 */
    rule->filter.filter_bm = PBR_FILTER_SRC_IP | PBR_FILTER_DST_IP;
    rule->filter.src_ip = entry->match.src_prefix;
    rule->filter.dst_ip = entry->match.dst_prefix;

    /* 填充动作：指向 MIDR 专用的路由表 */
    rule->action.flags = PBR_ACTION_TABLE;
    rule->action.table = MIDR_PBR_TABLE_BASE + entry->action.target_group;

    /* 通过 ZAPI 下发 */
    return zapi_pbr_rule_encode(zclient->obuf, rule);
}

/* 安装 source-based 路由到指定 table */
static void midr_pbr_install_group_table(struct bgp *bgp,
                                          uint8_t group_id,
                                          struct midr_path_result *result)
{
    struct zapi_route api = {};
    uint32_t table_id = MIDR_PBR_TABLE_BASE + group_id;

    zapi_route_init(&api);
    api.type = ZEBRA_ROUTE_BGP;
    api.safi = SAFI_UNICAST;
    api.vrf_id = bgp->vrf_id;
    api.prefix = result->paths[0].nexthop; /* 或者目的前缀 */
    api.tableid = table_id;

    /* 填充 nexthop */
    for (int i = 0; i < result->path_count && i < MULTIPATH_NUM; i++) {
        struct zapi_nexthop *znh = &api.nexthops[i];
        znh->gate = result->paths[i].nexthop;
        znh->type = NEXTHOP_TYPE_IPV6;
        znh->weight = result->paths[i].weight;
    }

    SET_FLAG(api.message, ZAPI_MESSAGE_NEXTHOP | ZAPI_MESSAGE_TABLEID);
    zclient_route_send(ZEBRA_ROUTE_ADD, bgp_zclient, &api);
}
```

### 2.5 AS-path 约束

AS-path 约束在控制平面实现（SPF 计算时排除），数据平面只需要携带 avoid_as 列表：

```c
/* bgpd/bgp_midr_spf.c — AS-path 约束集成 */

static void midr_spf_apply_as_constraint(struct ls_edge *edge,
                                          struct midr_path_ext *path)
{
    /* 如果该链路属于 avoid_as 中的 AS */
    for (int i = 0; i < path->avoid_as_count; i++) {
        if (edge->remote_as == path->avoid_as[i]) {
            /* 标记此路径不可用 (权重设为 0) */
            path->weight = 0;
            path->metric = INFINITY_METRIC;
            return;
        }
    }
}
```

---

## 三、负载均衡子系统

### 3.1 两级负载均衡架构

MIDR 的路由是两层结构：**Group 内路径** 和 **Group 间路径**，对应两级负载均衡：

```
         ┌──────────────────────────────────────┐
         │       目的前缀 D                      │
         └──────────────────┬───────────────────┘
                            │
                    ┌───────┴───────┐
                    │   Group 级 LB  │  ← 在 group 间分配流量
                    └───────┬───────┘
                            │
              ┌─────────────┼─────────────┐
              │             │             │
              ▼             ▼             ▼
        ┌──────────┐ ┌──────────┐ ┌──────────┐
        │ Group A  │ │ Group B  │ │ Group C  │
        │ 出口路径  │ │ 出口路径  │ │ 出口路径  │
        └────┬─────┘ └────┬─────┘ └────┬─────┘
             │            │            │
       ┌─────┴─────┐ ┌────┴────┐ ┌────┴────┐
       │ Path级 LB  │ │Path级 LB│ │Path级 LB│  ← group 内部 ECMP/UCMP
       └─────┬─────┘ └────┬────┘ └────┬────┘
             │            │            │
             ▼            ▼            ▼
          Kernel FIB → nexthop groups
```

### 3.2 两级权重计算

```c
/* bgpd/bgp_midr_lb.h — 新增 */

struct midr_lb_config {
    uint8_t enable_group_lb;        /* 启用 group 级负载均衡 */
    uint8_t group_lb_algo;          /* 0=ECMP, 1=按带宽加权, 2=按延迟加权 */
    uint8_t path_lb_algo;           /* 0=ECMP, 1=UCMP, 2=per-flow */
    uint32_t per_flow_seed;         /* per-flow hash 种子 */
};

/* Group 级权重 */
struct midr_group_weight {
    uint8_t  group_id;              /* 出口 Group ID */
    float    group_avail_bw;        /* 该 group 瓶颈带宽 (Mbps) */
    float    group_delay;           /* 该 group 平均延迟 (us) */
    uint8_t  group_weight;          /* 计算出的权重 (1-255) */
};

/* 两级权重计算结果 */
struct midr_lb_result {
    uint8_t  group_count;           /* 参与负载均衡的 group 数 */
    struct midr_group_weight groups[MIDR_GROUP_ID_MAX];

    uint8_t  total_path_count;      /* 总路径数 (所有 group) */
    struct {
        uint8_t  path_id;           /* 路径编号 */
        uint8_t  owner_group;       /* 所属 group */
        uint8_t  final_weight;      /* 最终权重: group_weight × path_weight / 255 */
        union g_addr nh;
    } paths[MIDR_MAX_PATHS];
};
```

### 3.3 负载均衡算法

```c
/* bgpd/bgp_midr_lb.c — 新增 */

/* 计算公式 */
static void midr_lb_compute_group_weights(struct midr_lb_result *lb,
                                           uint8_t algo)
{
    float total_bw = 0, total_delay = 0;
    float inv_delay;

    switch (algo) {
    case 0: /* ECMP: 所有 group 等权重 */
        for (int i = 0; i < lb->group_count; i++)
            lb->groups[i].group_weight = 255 / lb->group_count;
        break;

    case 1: /* 按带宽加权 */
        for (int i = 0; i < lb->group_count; i++)
            total_bw += lb->groups[i].group_avail_bw;
        for (int i = 0; i < lb->group_count; i++)
            lb->groups[i].group_weight =
                (uint8_t)(lb->groups[i].group_avail_bw / total_bw * 255);
        break;

    case 2: /* 按延迟加权 (延迟越低权重越高) */
        for (int i = 0; i < lb->group_count; i++)
            total_delay += lb->groups[i].group_delay ?
                           1.0f / lb->groups[i].group_delay : 0;
        for (int i = 0; i < lb->group_count; i++) {
            inv_delay = lb->groups[i].group_delay ?
                        1.0f / lb->groups[i].group_delay : 0;
            lb->groups[i].group_weight =
                (uint8_t)(inv_delay / total_delay * 255);
        }
        break;
    }
}

/* 两级权重合并 */
static void midr_lb_merge_weights(struct midr_lb_result *lb,
                                   struct midr_path_ext *paths,
                                   uint8_t path_count)
{
    for (int i = 0; i < path_count; i++) {
        /* 找到对应 group 的权重 */
        uint8_t gw = 255; /* 默认等权重 */
        for (int j = 0; j < lb->group_count; j++) {
            if (lb->groups[j].group_id == paths[i].path_owner_group) {
                gw = lb->groups[j].group_weight;
                break;
            }
        }
        /* 最终权重 = group_weight × path_weight / 255 */
        uint16_t fw = (uint16_t)gw * paths[i].weight / 255;
        lb->paths[lb->total_path_count++] = (typeof(*lb->paths)){
            .path_id = i,
            .owner_group = paths[i].path_owner_group,
            .final_weight = (uint8_t)(fw ? fw : (gw ? 1 : 0)),
            .nh = paths[i].nexthop,
        };
    }
}
```

### 3.4 Per-flow 负载均衡

对需要保持 flow 一致性的流量（如 TCP），支持 per-flow hash：

```c
/* 在 midr_zebra_route_add() 中设置 per-flow 参数 */
void midr_set_perflow_lb(struct zapi_route *api,
                          struct midr_lb_config *cfg)
{
    if (cfg->path_lb_algo == 2) { /* per-flow */
        /* 内核 ECMP 基于 5-tuple hash 自然实现 per-flow */
        /* 不设置 weight，内核自动做 per-flow 均衡 */
        SET_FLAG(api->flags, ZEBRA_FLAG_PER_FLOW_LB);
    }
}
```

---

## 四、跨 Group 隧道与 SRv6 集成

### 4.1 跨 Group 转发模型

```
    Group A                    Group B                    Group C
  ┌───────────┐           ┌───────────┐           ┌───────────┐
  │  R1 ──────┼───────────│──── R2    │           │  R4       │
  │    \      │  Group    │   /       │           │   │       │
  │     R3───┼───────────│──/        │           │   R5       │
  └───────────┘  Link    └───────────┘           └───────────┘
       │                                             │
       │═════════════════════════════════════════════│
       │        SRv6 Policy Tunnel                   │
       └─────────────────────────────────────────────┘
```

跨 group 转发的关键：

1. **Group 内**：使用普通 BGP-LS SPF，走 ECMP/UCMP
2. **Group 间**：使用 SRv6 Policy 封装，入口 group 打上 SID 栈，出口 group 解封装
3. **跨多 group**：通过 ingress SID + egress SID 构造端到端隧道

### 4.2 跨 Group 路径结构

```c
/* bgpd/bgp_midr_cross_group.h — 新增 */

/* 跨 group 隧道信息 */
struct midr_cross_group_tunnel {
    uint8_t     ingress_group_id;   /* 入口 group */
    uint8_t     egress_group_id;    /* 出口 group */
    uint32_t    tunnel_id;          /* 隧道 ID (用于 zebra 标识) */

    /* SRv6 Policy 参数 */
    struct in6_addr bsid;           /* Binding SID */
    struct in6_addr segment_list[SRV6_MAX_SEGS]; /* SID 列表 */
    uint8_t        segment_count;

    /* TE 参数 */
    uint32_t    delay;              /* 隧道延迟 (us) */
    uint32_t    te_metric;          /* TE 度量 */

    /* 保护 */
    uint8_t     protection;         /* 0=无, 1=hot-standby, 2=1:1 */
    struct in6_addr protect_sid_list[SRV6_MAX_SEGS];
    uint8_t        protect_seg_count;
};
```

### 4.3 SRv6 隧道下发

```c
/* bgpd/bgp_midr_srv6.c — 新增 */

/* 安装跨 group SRv6 Policy 隧道 */
void midr_srv6_install_cross_group_tunnel(struct bgp *bgp,
        struct midr_cross_group_tunnel *tunnel)
{
    struct zapi_route api = {};
    struct zapi_nexthop *znh;

    /* 构造内部前缀 (tunnel 标识) */
    struct prefix p = {
        .family = AF_INET6,
        .prefixlen = 128,
        .u.prefix6 = tunnel->bsid,
    };

    zapi_route_init(&api);
    api.type = ZEBRA_ROUTE_BGP;
    api.safi = SAFI_UNICAST;
    api.vrf_id = bgp->vrf_id;
    api.prefix = p;

    znh = &api.nexthops[0];
    api.nexthop_num = 1;

    /* 封装 SRv6 */
    znh->seg_num = tunnel->segment_count;
    for (int i = 0; i < tunnel->segment_count && i < SRV6_MAX_SEGS; i++)
        znh->seg6_segs[i] = tunnel->segment_list[i];
    znh->srv6_encap_behavior = SRV6_HEADEND_BEHAVIOR_H_ENCAPS;
    SET_FLAG(znh->flags, ZAPI_NEXTHOP_FLAG_SEG6);

    SET_FLAG(api.message, ZAPI_MESSAGE_NEXTHOP);
    zclient_route_send(ZEBRA_ROUTE_ADD, bgp_zclient, &api);
}
```

---

## 五、数据平面集成

### 5.1 更新后的统一入口函数

```c
/* bgpd/bgp_midr_zebra.c — 增强版 */

void midr_zebra_route_add(struct bgp *bgp,
                           struct prefix *p,
                           struct midr_path_result *result)
{
    struct zapi_route api = {};
    enum midr_mode mode;

    zapi_route_init(&api);
    api.type = ZEBRA_ROUTE_BGP;
    api.safi = SAFI_UNICAST;
    api.vrf_id = bgp->vrf_id;
    api.prefix = *p;

    /* ---- 新增: Group 上下文感知 ---- */
    if (result->group_ctx.group_id) {
        /* 使用 group 专属路由表 */
        api.tableid = MIDR_ROUTE_TABLE_BASE + result->group_ctx.group_id;
        SET_FLAG(api.message, ZAPI_MESSAGE_TABLEID);
    }

    /* ---- 新增: 策略标签 ---- */
    if (result->steer_mode) {
        SET_FLAG(api.flags, ZEBRA_FLAG_POLICY_ROUTING);
    }

    /* ---- 模式检测 ---- */
    mode = midr_detect_mode(result->paths, result->path_count);

    switch (mode) {
    case MIDR_MODE_BASIC:
        midr_zebra_fill_basic(&api, result->paths);
        break;
    case MIDR_MODE_ECMP:
        midr_zebra_fill_ecmp(&api, result->paths, result->path_count);
        break;
    case MIDR_MODE_UCMP:
        midr_zebra_fill_ucmp(&api, result->paths, result->path_count);
        break;
    case MIDR_MODE_SRV6:
        midr_zebra_fill_srv6_ext(&api, result->paths,
                                  result->path_count,
                                  &result->cross_group);
        break;
    case MIDR_MODE_CROSS_GROUP:
        midr_zebra_fill_cross_group(&api, result);
        break;
    }

    SET_FLAG(api.message, ZAPI_MESSAGE_NEXTHOP);
    zclient_route_send(ZEBRA_ROUTE_ADD, bgp_zclient, &api);
}
```

### 5.2 模式检测增强

```c
enum midr_mode {
    MIDR_MODE_BASIC,            /* 单路径纯 IP */
    MIDR_MODE_ECMP,             /* 等权重多路径 */
    MIDR_MODE_UCMP,             /* 加权多路径 */
    MIDR_MODE_SRV6,             /* SRv6 严格路径 */
    MIDR_MODE_CROSS_GROUP,      /* 跨 group 路径 (new) */
};

enum midr_mode midr_detect_mode_ext(struct midr_path_ext *paths,
                                     uint8_t path_count)
{
    /* 检测跨 group */
    for (int i = 0; i < path_count; i++) {
        if (paths[i].is_cross_group)
            return MIDR_MODE_CROSS_GROUP;
    }

    /* 检测 SRv6 */
    for (int i = 0; i < path_count; i++) {
        if (paths[i].sid_count > 0 || paths[i].tunnel_sid_count > 0)
            return MIDR_MODE_SRV6;
    }

    /* 检测 UCMP */
    if (path_count > 1 && paths[0].weight > 0)
        return MIDR_MODE_UCMP;

    /* 检测 ECMP */
    if (path_count > 1)
        return MIDR_MODE_ECMP;

    return MIDR_MODE_BASIC;
}
```

### 5.3 跨 Group 路径填充

```c
static void midr_zebra_fill_cross_group(struct zapi_route *api,
                                         struct midr_path_result *result)
{
    /* 跨 group 路径: 每个路径可能附带隧道 SID */
    for (int i = 0; i < result->path_count && i < MULTIPATH_NUM; i++) {
        struct zapi_nexthop *znh = &api->nexthops[i];
        struct midr_path_ext *pe = &result->paths[i];

        znh->gate = pe->nexthop;
        znh->type = NEXTHOP_TYPE_IPV6;

        if (pe->tunnel_sid_count > 0) {
            /* 跨 group 使用 SRv6 封装 */
            znh->seg_num = pe->tunnel_sid_count;
            znh->seg6_segs[0] = pe->tunnel_sid;
            znh->srv6_encap_behavior = SRV6_HEADEND_BEHAVIOR_H_ENCAPS;
            SET_FLAG(znh->flags, ZAPI_NEXTHOP_FLAG_SEG6);
        }

        /* 两级权重 */
        znh->weight = pe->weight;
        if (pe->weight > 0)
            SET_FLAG(znh->flags, ZAPI_NEXTHOP_FLAG_WEIGHT);

        /* Group 标签 (用于 zebra 策略路由) */
        if (result->group_ctx.group_id)
            znh->srte_color = (uint32_t)result->group_ctx.group_id << 16
                            | result->paths[i].color;
    }
    api->nexthop_num = result->path_count;
}
```

---

## 六、CLI 配置接口

### 6.1 策略路由配置

```
midr-router(config)# midr policy
midr-router(config-midr-policy)# policy-entry 10
midr-router(config-midr-policy-entry)# match src-prefix 2001:db8:1::/48
midr-router(config-midr-policy-entry)# match dst-prefix 2001:db8:2::/48
midr-router(config-midr-policy-entry)# match src-group 1
midr-router(config-midr-policy-entry)# match dst-group 2
midr-router(config-midr-policy-entry)# match avoid-as 64500 64501
midr-router(config-midr-policy-entry)# match color 100
midr-router(config-midr-policy-entry)# action steer-group 3
midr-router(config-midr-policy-entry)# action steer-color 200
midr-router(config-midr-policy-entry)# action drop
midr-router(config-midr-policy-entry)# exit
midr-router(config-midr-policy)# exit
```

### 6.2 负载均衡配置

```
midr-router(config)# midr load-balance
midr-router(config-midr-lb)# group-lb-algo bandwidth   {ecmp | bandwidth | delay}
midr-router(config-midr-lb)# path-lb-algo per-flow     {ecmp | ucmp | per-flow}
midr-router(config-midr-lb)# per-flow-seed 12345
midr-router(config-midr-lb)# group 1 weight 80
midr-router(config-midr-lb)# group 2 weight 20
midr-router(config-midr-lb)# exit
```

### 6.3 监控命令

```
midr-router# show midr policy
midr-router# show midr policy statistics
midr-router# show midr load-balance
midr-router# show midr cross-group tunnels
midr-router# show midr routes group <1-255>
midr-router# show ip route table midr-1   (查看 group 1 的路由表)
```

---

## 七、文件变更清单

| 操作 | 文件 | 说明 |
|------|------|------|
| **修改** | `bgpd/bgp_midr_zebra.c` | 增强数据结构、新增 CROSS_GROUP 模式、策略标签支持、per-flow LB |
| **修改** | `bgpd/bgp_midr_zebra.h` | 增强 `midr_path_result`，新增 `midr_path_ext`、`midr_group_info` |
| **新增** | `bgpd/bgp_midr_pbr.c/h` | 策略路由引擎、PBR 规则下发、策略匹配 |
| **新增** | `bgpd/bgp_midr_lb.c/h` | 两级负载均衡、权重计算、per-flow 支持 |
| **新增** | `bgpd/bgp_midr_srv6.c/h` | 跨 group SRv6 隧道管理、BSID 安装 |
| **新增** | `bgpd/bgp_midr_cross_group.c/h` | 跨 group 路由逻辑、隧道生命周期 |
| **修改** | `bgpd/bgp_midr_nht.c` | 支持跨 group nexthop tracking |
| **新增** | `bgpd/bgp_midr_vty.c` | CLI 配置命令 |

--- 

## 八、与现有设计的兼容性

| 现有模式 | 增强后 | 兼容性 |
|---------|--------|--------|
| `midr_path_result` | `midr_path_result` (扩展) | 二进制兼容：新增字段全在末尾，旧代码使用 `.paths[].weight` 仍可工作 |
| `midr_zebra_route_add()` | 增强版 | API 签名不变，新增字段通过 result 结构体传入 |
| `bgp_zclient` | 复用 | 不变 |
| zebra 模块 | 不变 | 不修改 zebra 任何代码 |
| `bgp_nht.c` | 1 行 hook | 不变 |

### 8.1 迁移路径

1. **Phase 1** (当前): 纯 IP 路由 (BASIC/ECMP/UCMP) + SRv6 基本封装
2. **Phase 2** (本次设计): 加入分组感知 + 策略路由 + 两级负载均衡 + 跨 group 隧道
3. **Phase 3** (未来): 动态 group 发现、自适应负载均衡、AI 驱动策略优化