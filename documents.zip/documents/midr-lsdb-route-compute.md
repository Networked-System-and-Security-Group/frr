# MIDR LSDB 存储同步与路由计算下发全流程

## 概述

本文档说明 MIDR 的三条关键链路：

1. **LSDB 的存储结构**：TED 如何组织网络拓扑
2. **LSDB 的同步方法**：IGP → zebra → BGP-LS 的跨进程通信
3. **路由计算与下发的完整流程**：从 TED 更新到内核 FIB 的端到端操作顺序
4. **SRv6/TE/负载均衡的协同层次关系**

---

## 一、LSDB 存储结构：TED（Traffic Engineering Database）

### 1.1 内存中的三层结构

```
FRR 进程 bgpd 内存空间
┌────────────────────────────────────────────────────────────────┐
│                        TED (ls_ted)                            │
│  ┌──────────────────────────────────────────────────────────┐  │
│  │  vertices (RB-Tree, key=mpls_label/ipv4_addr/ipv6_addr)  │  │
│  │  ┌─────────────┐  ┌─────────────┐  ┌─────────────┐     │  │
│  │  │ ls_vertex A │  │ ls_vertex B │  │ ls_vertex C │ ... │  │
│  │  │ ├node       │  │ ├node       │  │ ├node       │     │  │
│  │  │ ├out_edges──┼──┼──>         │  │ ├out_edges──┼──┐  │  │
│  │  │ ├in_edges───┼──┼──>         │  │ │            │  │  │  │
│  │  │ └prefixes───┼──┼──>         │  │ └────────────┘  │  │  │
│  │  └──────┬──────┘  └─────────────┘                   │  │  │
│  │         │                                            │  │  │
│  │         ▼                                            ▼  │  │
│  │  ┌──────────────────────────────────────────────────┐  │  │
│  │  │  edges (RB-Tree, key=local_addr/remote_addr/id)     │  │
│  │  │  ┌──────────────┐  ┌──────────────┐  ┌──────────┐ │  │
│  │  │  │ ls_edge A→B  │  │ ls_edge B→A  │  │ ls_edge  │ │  │
│  │  │  │ ├attributes  │  │ ├attributes  │  │ A→C ...  │ │  │
│  │  │  │ │ ├te_metric │  │ │ ├te_metric │  └──────────┘ │  │
│  │  │  │ │ ├delay     │  │ │ ├delay     │               │  │
│  │  │  │ │ ├ava_bw    │  │ │ ├ava_bw    │               │  │
│  │  │  │ │ └admin_grp │  │ │ └admin_grp │               │  │
│  │  │  │ ├source=A   │  │ ├source=B   │               │  │
│  │  │  │ └dest=B     │  │ └dest=A     │               │  │
│  │  │  └──────────────┘  └──────────────┘               │  │
│  │  └──────────────────────────────────────────────────┘  │  │
│  │                                                        │  │
│  │  subnets (RB-Tree, key=prefix)                         │  │
│  │  ┌──────────────┐  ┌──────────────┐                    │  │
│  │  │ ls_subnet    │  │ ls_subnet    │                    │  │
│  │  │ pre=10.0/24  │  │ pre=2001::/48│                    │  │
│  │  │ ├vertex=A    │  │ ├vertex=B    │                    │  │
│  │  │ └ls_pref     │  │ └ls_pref     │                    │  │
│  │  │  ├metric     │  │  ├metric     │                    │  │
│  │  │  └srv6.sid   │  │  └srv6.sid   │                    │  │
│  │  └──────────────┘  └──────────────┘                    │  │
│  └──────────────────────────────────────────────────────────┘  │
└────────────────────────────────────────────────────────────────┘
```

### 1.2 关键数据结构关系

| 结构 | 物理容器 | 逻辑含义 | 组织方式 | 查找 key |
|------|---------|---------|---------|---------|
| `ls_ted` | `struct bgp_ls. ted` | 整个拓扑数据库 | 单例 | 无 |
| `ls_vertex` | `ted->vertices` (RB-Tree) | 网络节点(路由器) | 节点红黑树 | 64-bit hash key |
| `ls_edge` | `ted->edges` (RB-Tree) | 单向链路 | 边红黑树 | `{family, addr/link_id}` |
| `ls_subnet` | `ted->subnets` (RB-Tree) | 附属前缀 | 前缀红黑树 | `prefix` |
| `ls_node` | `vertex->node` | 节点属性(SRGB/SRv6/Router-ID) | 1:1 关联 | — |
| `ls_attributes` | `edge->attributes` | 链路 TE 属性(带宽/延迟等) | 1:1 关联 | — |
| `ls_prefix` | `subnet->ls_pref` | 前缀属性(SID/metric) | 1:1 关联 | — |

### 1.3 节点间关系

```
ls_vertex A
├── node          → ls_node (router-id, SRGB, SRv6 locator)
├── outgoing_edges→ list of ls_edge pointers (A→B, A→C, ...)
├── incoming_edges→ list of ls_edge pointers (B→A, C→A, ...)
└── prefixes      → list of ls_subnet pointers (10.0.0.0/24, ...)

ls_edge A→B
├── source        → ls_vertex A
├── destination   → ls_vertex B
└── attributes    → ls_attributes (metric, te_metric, delay, ava_bw, ...)
```

---

## 二、LSDB 同步方法：ZAPI Opaque 消息机制

### 2.1 整体架构

```
                    IGP 域内              BGP-LS 域间
               ┌──────────┐          ┌──────────────┐
               │ ospfd/   │          │ 远程 BGP-LS   │
               │ isisd    │          │ 邻居          │
               └────┬─────┘          └──────┬───────┘
                    │ LS 消息               │ BGP UPDATE
                    │ (ZAPI OPAQUE)         │ (BGP-LS NLRI)
                    ▼                       ▼
               ┌──────────────────────────────────────┐
               │              zebra                   │
               │                                      │
               │   ┌──────────────────────────────┐   │
               │   │  Link-State Message 中继     │   │
               │   │                              │   │
               │   │  IGP Side:                   │   │
               │   │  ospfd/isisd → zebra         │   │
               │   │  (ZAPI OPAQUE LINK_STATE)    │   │
               │   │                              │   │
               │   │  BGP Side:                   │   │
               │   │  zebra → bgpd                │   │
               │   │  (ZAPI OPAQUE LINK_STATE)    │   │
               │   └──────────────────────────────┘   │
               └────────────────┬─────────────────────┘
                                │ ZAPI OPAQUE
                                ▼
               ┌──────────────────────────────────────┐
               │              bgpd                    │
               │                                      │
               │  ┌──────────────────────────────┐    │
               │  │   bgp_ls_ted.c                │    │
               │  │   ls_msg2vertex/edge/subnet   │    │
               │  │   → TED 更新                   │    │
               │  │   → BGP-LS NLRI 发布           │    │
               │  └──────────────────────────────┘    │
               │                                      │
               │  ┌──────────────────────────────┐    │
               │  │   bgp_midr_spf.c (MIDR)      │    │
               │  │   TED 变化 → SPF 触发         │    │
               │  │   → 路径计算                  │    │
               │  │   → 路由下发                  │    │
               │  └──────────────────────────────┘    │
               └──────────────────────────────────────┘
```

### 2.2 ZAPI Opaque Link State 消息类型

```c
/* lib/zclient.h — 注册表 */
enum zapi_opaque_registry {
    LINK_STATE_SYNC = 1,      /* 全量同步 */
    LINK_STATE_UPDATE = 2,    /* 增量更新 */
};

/* lib/link_state.h — 消息事件 */
#define LS_MSG_EVENT_SYNC   1  /* 全量同步 (db 请求后) */
#define LS_MSG_EVENT_ADD    2  /* 新增元素 */
#define LS_MSG_EVENT_UPDATE 3  /* 更新元素 */
#define LS_MSG_EVENT_DELETE 4  /* 删除元素 */

/* lib/link_state.h — 消息子类型 */
#define LS_MSG_TYPE_NODE      1  /* 节点信息 */
#define LS_MSG_TYPE_ATTRIBUTES 2  /* 链路属性 */
#define LS_MSG_TYPE_PREFIX   3  /* 前缀信息 */
```

### 2.3 同步流程详解

```
A. 初始化阶段 (Full Sync)
   ────────────────────
   bgpd                                      ospfd/isisd
     │                                          │
     │  1. ls_register(zclient, false)           │
     │     → 注册为 OPAQUE 客户端                 │
     │                                          │
     │  2. ls_request_sync(zclient)              │
     │     → ZAPI OPAQUE: LINK_STATE_SYNC        │
     │                                          │
     │                                          │
     │                           3. zebra 收到 SYNC 请求
     │                              → 转发给所有 LS Server (ospfd/isisd)
     │                                          │
     │                             4. ospfd/isisd → zebra
     │                                → 逐条发送所有 LS 元素
     │                                   (Event=SYNC, Type=NODE/ATTR/PREFIX)
     │                                          │
     │  5. zebra → bgpd                          │
     │     → stream 解码 → ls_stream2ted()       │
     │     → TED 完整构建                         │
     │     → bgp_ls_process_message()             │
     │       → BGP-LS NLRI 产出                   │
     │                                          │

B. 增量更新 (Incremental Update)
   ──────────────────────
   ospfd/isisd 检测到 IGP LSA/LSP 变化
     │
     │  1. 解析 IGP 变化 → 构造 ls_message
     │     → ls_vertex2msg() / ls_edge2msg() / ls_subnet2msg()
     │     → event = ADD/UPDATE/DELETE
     │
     │  2. ls_send_msg(zclient, msg, NULL)
     │     → ZAPI OPAQUE: LINK_STATE_UPDATE
     │
     │  3. zebra 接收 → 广播给所有注册的客户端 (bgpd)
     │
     │  4. bgpd 接收:
     │     a) zebra → bgp_ls_process_linkstate_message()
     │     b) → ls_msg2vertex/edge/subnet() → TED 更新
     │     c) → bgp_ls_update/withdraw() → BGP-LS NLRI 更新
     │     d) → __触发 MIDR SPF 重算__
     │
     │  5. BGP-LS NLRI 通过 IBGP 发布给域外邻居
     │     → 远程 bgpd 收到 → 更新本地 TED
     │     → 跨域拓扑一致性
```

### 2.4 跨域 LSDB 同步

```
         AS 65001                     AS 65002
    ┌──────────────┐           ┌──────────────┐
    │  bgpd R1     │           │  bgpd R4     │
    │              │           │              │
    │  ┌────────┐  │  BGP-LS   │  ┌────────┐  │
    │  │ TED A  │  │ UPDATE   │  │ TED B  │  │
    │  │        │◄─┼──────────┼──┤        │  │
    │  │ 节点A  │  │ NLRI 1-6 │  │ 节点B  │  │
    │  │ 链路A  │  │          │  │ 链路B  │  │
    │  │ 前缀A  │  │          │  │ 前缀B  │  │
    │  └────────┘  │           │  └────────┘  │
    │              │           │              │
    │  MIDR SPF    │           │  MIDR SPF    │
    │  (Group 内)  │           │  (Group 内)  │
    └──────────────┘           └──────────────┘
              │                      │
              │  Group-Link State    │
              │  (压缩版 BGP-LS,     │
              │   只含 Group 边界     │
              │   和 Group 级度量)   │
              └──────────────────────┘
                         │
                         ▼
               MIDR Group SPF
               (跨 Group 路径计算)
```

---

## 三、路由计算与下发的完整流程

### 3.1 全局操作顺序

```
时间线 →
═══════════════════════════════════════════════════════════════════

 触发事件: IGP LSA 变化 (链路 up/down/度量变化)
     │
     ▼
[Layer 0] TED 更新 (bgp_ls_ted.c)
     │ ls_msg2edge() → TED 中对应 edge 更新
     │ 涉及: ls_attributes 中的 te_metric/delay/ava_bw
     │
     ▼
[Layer 1] BGP-LS NLRI 发布 (bgp_ls.c)
     │ bgp_ls_originate_link() → BGP UPDATE 给 IBGP 邻居
     │
     ▼
[Layer 2] MIDR SPF 触发 (bgp_midr_spf.c)
     │ bgp_midr_spf_run():
     │   ├── Step 1: 更新 Group 信息
     │   │    ├── 检查该 edge 属于哪个 Group
     │   │    └── 更新 Group-Link-State 摘要
     │   │
     │   ├── Step 2: Group 内 SPF
     │   │    ├── 算法: Dijkstra
     │   │    ├── 度量: IGP / TE / Delay (按配置)
     │   │    └── 输出: Group 内所有前缀的下一跳
     │   │
     │   ├── Step 3: Group 间 SPF
     │   │    ├── 算法: Dijkstra on Group Graph
     │   │    ├── 输入: Group-Link-State
     │   │    ├── 约束: AS-path, affinity (来自 Policy)
     │   │    └── 输出: 跨 Group 的出口 Group
     │   │
     │   └── Step 4: 对每个受影响前缀:
     │        ├── 有 Policy 匹配吗？
     │        │   ├── Yes → 应用 Policy 约束
     │        │   │      → midr_pbr_match() 修改权重/路径
     │        │   └── No → 使用默认 SPF 结果
     │        │
     │        └── 构造 midr_path_result
     │
     ▼
[Layer 3] CSPF 约束优化 (bgp_midr_cspf.c) [可选]
     │ 仅当配置了 TE 约束 (max-delay/min-bw/affinity) 时执行
     │ midr_cspf_compute():
     │   ├── Step 1: 剪枝 (prune) — 排除不满足约束的链路
     │   ├── Step 2: K-SPF (Yen's algorithm)
     │   ├── Step 3: 构造 SID 列表 (如需 SRv6)
     │   └── 输出: K 条最优路径
     │
     ▼
[Layer 4] 负载均衡权重计算 (bgp_midr_lb.c)
     │ midr_lb_compute_group_weights():
     │   ├── Group 内: 按 path 的 ava_bw/te_metric 计算 path weight
     │   └── Group 间: 按 Group 级度量计算 group weight
     │
     │ midr_lb_merge_weights():
     │   ├── 最终权重 = group_weight * path_weight / 255
     │   └── 输出: 带权重的 path 列表
     │
     ▼
[Layer 5] 数据平面下发 (bgp_midr_zebra.c)
     │ midr_zebra_route_add():
     │   ├── Step 1: 模式检测
     │   │    ├── sid_count>0 → MIDR_MODE_SRV6
     │   │    ├── is_cross_group → MIDR_MODE_CROSS_GROUP
     │   │    ├── weight>0 → MIDR_MODE_UCMP
     │   │    ├── path_count>1 → MIDR_MODE_ECMP
     │   │    └── default → MIDR_MODE_BASIC
     │   │
     │   ├── Step 2: 填充 zapi_route
     │   │    ├── prefix, vrf_id, tableid (Group 专属表)
     │   │    ├── type = ZEBRA_ROUTE_BGP
     │   │    └── flags = ALLOW_RECURSION
     │   │
     │   ├── Step 3: 填充 zapi_nexthop[]
     │   │    ├── gate = path.nexthop
     │   │    ├── type = NEXTHOP_TYPE_IPV6
     │   │    ├── weight = final_weight
     │   │    ├── SRv6: seg6_segs[], srv6_encap_behavior
     │   │    ├── UCMP: ZAPI_NEXTHOP_FLAG_WEIGHT
     │   │    └── Cross-Group: tableid + PBR rule
     │   │
     │   └── Step 4: 存到 pending (批量聚合)
     │
     ▼
[Layer 6] 批量下发 (bgp_midr_zebra.c)
     │ 100ms 后 / 或 midr_zebra_route_flush():
     │   ├── 删除 pending.dels 中的前缀
     │   ├── 安装 pending.adds 中的前缀
     │   └── 通过 zclient_route_send() → ZAPI
     │
     ▼
[Layer 7] zebra → 内核 FIB
     │ zapi_msg → zebra_rib → zebra_nhg → dplane → rt_netlink
     │   ├── 单路径: RTM_NEWROUTE + NTA_GATEWAY
     │   ├── ECMP: RTM_NEWROUTE + RTA_MULTIPATH
     │   ├── UCMP: RTM_NEWROUTE + RTA_MULTIPATH + weight
     │   ├── SRv6: LWTUNNEL_ENCAP_SEG6 + segs[]
     │   └── Cross-Group: + PBR rule (ZEBRA_RULE_ADD)
     │
     ▼
  Linux Kernel FIB 更新 → 转发生效
```

### 3.2 时序图（完整端到端）

```
ospfd         zebra          bgpd(TED)     bgpd(MIDR)      Kernel
  │             │               │              │              │
  │  LSA Change │               │              │              │
  │────────────>│               │              │              │
  │             │ LS_MSG_UPDATE │              │              │
  │             │──────────────>│              │              │
  │             │               │ 更新 TED     │              │
  │             │               │──────┐       │              │
  │             │               │      │       │              │
  │             │               │<─────┘       │              │
  │             │               │              │              │
  │             │               │ 触发 SPF     │              │
  │             │               │─────────────>│              │
  │             │               │              │              │
  │             │               │              │  Dijkstra    │
  │             │               │              │──────┐       │
  │             │               │              │      │       │
  │             │               │              │<─────┘       │
  │             │               │              │              │
  │             │               │              │  有 Policy?  │
  │             │               │              │──────┐       │
  │             │               │              │      │       │
  │             │               │              │<─────┘       │
  │             │               │              │              │
  │             │               │              │  CSPF (可选) │
  │             │               │              │──────┐       │
  │             │               │              │      │       │
  │             │               │              │<─────┘       │
  │             │               │              │              │
  │             │               │              │  LB 权重计算 │
  │             │               │              │──────┐       │
  │             │               │              │      │       │
  │             │               │              │<─────┘       │
  │             │               │              │              │
  │             │               │              │ ZEBRA_ROUTE_ADD
  │             │               │              │─────────────>│
  │             │               │              │              │
  │             │               │              │  Netlink     │
  │             │               │              │──────┐       │
  │             │               │              │      │       │
  │             │               │              │<─────┘       │
  │             │               │              │              │
  │             │               │              │  FIB Updated │
  │             │               │              │<─────────────│
  │             │               │              │              │
```

### 3.3 时序关键参数

| 阶段 | 操作 | 典型耗时 | 说明 |
|------|------|---------|------|
| T0 | IGP LSA → ospfd | ~10ms | OSPF 泛洪收敛 |
| T1 | ospfd → zebra (LS MSG) | <1ms | 本地进程通信 |
| T2 | zebra → bgpd (LS MSG) | <1ms | 本地进程通信 |
| T3 | bgpd TED 更新 | <1ms | 内存拓扑更新 |
| T4 | BGPLS NLRI 发布 | ~50ms | IBGP 发布给对等体 |
| T5 | MIDR SPF 重算 | 1-50ms | 取决于拓扑大小 |
| T6 | CSPF (可选) | 5-500ms | K-SPF 多路径搜索 |
| T7 | 权重计算 | <1ms | 简单数学运算 |
| T8 | 批量等待 | 100ms | 防抖聚合窗口 |
| T9 | ZAPI 下发 | ~5ms | Unix Socket |
| T10 | zebra → Netlink → FIB | ~1ms | 内核路由更新 |

**端到端总时间**: T0~T10 ≈ 170ms-700ms (含防抖窗口)

---

## 四、SRv6/TE/负载均衡的协同层次

### 4.1 层次关系

```
                      ┌──────────────────┐
                      │   路由策略层      │  ← 最高优先级
                      │  (Policy Engine)  │     src/dst/color/AS 匹配
                      │  │               │
                      │  源路由 / AS 约束 │
                      └────────┬─────────┘
                               │ 匹配成功 → 跳过下层默认计算
                               │ 匹配失败 → 继续下层默认计算
                               ▼
              ┌─────────────────────────────────────┐
              │       CSPF 约束路径计算层            │
              │       (bgp_midr_cspf.c)              │← 受约束的最优化
              │                                      │
              │  剪枝 → K-SPF → SID List 构造       │
              │  约束: delay/bw/affinity/SRLG/AS     │
              │  度量: IGP/TE/Delay/Jitter/复合     │
              └────────────────┬────────────────────┘
                               │ 输出: K 条符合约束的路径
                               ▼
              ┌─────────────────────────────────────┐
              │       负载均衡加权层                 │
              │       (bgp_midr_lb.c)               │← 流量分配
              │                                      │
              │  Group 级权重 (基于 TE 聚合度量)     │
              │  Path 级权重 (基于 ava_bw/delay)     │
              │  最终权重 = group_w × path_w         │
              └────────────────┬────────────────────┘
                               │ 输出: 带权重的 path 列表
                               ▼
              ┌─────────────────────────────────────┐
              │       封装模式选择层                 │
              │       (bgp_midr_zebra.c)            │← 内核表示
              │                                      │
              │  .sid_count>0 → SRv6 H.Encaps       │
              │  .is_cross_group → 跨 Group 隧道    │
              │  .weight>0 → zapi weight flag       │
              │  .steer_mode → PBR rule + table     │
              └────────────────┬────────────────────┘
                               │ 输出: zapi_route + zapi_nexthop[]
                               ▼
              ┌─────────────────────────────────────┐
              │      批量延迟下发层                  │
              │      100ms 窗口聚合                  │← 防抖
              │      或立即 flush (紧急)             │
              └────────────────┬────────────────────┘
                               ▼
                          Linux Kernel FIB
```

### 4.2 数据结构的层次填充

```
midr_path_result (CP → DP 的统一载体)
│
├── group_ctx (分层 1: 分组信息)
│   ├── .group_id
│   ├── .is_cross_group
│   ├── .group_metric (来自 TED 聚合)
│   └── .group_te_metric (来自 TED 聚合)
│
├── paths[] (分层 2~4: 路径 + 权重 + 封装)
│   ├── .nexthop (基本下一跳)
│   ├── .metric / .te_metric / .avail_bw (CSPF 输出)
│   ├── .weight (LB 计算的最终权重)
│   ├── .path_owner_group (所属 Group)
│   ├── .sid_list[] / .sid_count (SRv6 封装)
│   ├── .tunnel_sid / .tunnel_sid_count (跨 Group 隧道)
│   └── .color / .affinity (策略标签)
│
├── cross_group (分层 3: 跨 Group 隧道)
│   ├── .tunnel_mode (=0 直连 / =1 SRv6)
│   ├── .ingress_sid
│   └── .egress_sid
│
└── steer_mode / policy_id (分层 0: 策略)
```

### 4.3 关键代码路径的调用层次

```c
/* ====== 入口: TED 变化触发路由重新计算 ====== */
void bgp_midr_spf_trigger(struct bgp *bgp)
{
    /* 异步触发 SPF (防频繁重算) */
    event_add_event(bgp->master, bgp_midr_spf_run, bgp, 0, &bgp->t_midr_spf);
}

/* ====== SPF 主函数: 从顶到下依次调用各模块 ====== */
static void bgp_midr_spf_run(struct event *event)
{
    struct bgp *bgp = EVENT_ARG(event);

    /* Layer 0: 更新 Group 分组信息 */
    bgp_midr_spf_update_groups(bgp, ted);

    /* Layer 1: Group 内 SPF */
    struct midr_spf_result intra = {};
    bgp_midr_spf_intra_group(bgp, ted, &intra);

    /* Layer 2: Group 间 SPF */
    struct midr_spf_result inter = {};
    bgp_midr_spf_inter_group(bgp, ted, &inter);

    /* 对每个受影响的 prefix: */
    for (int i = 0; i < prefix_count; i++) {
        struct midr_path_result result = {};

        /* Layer 3: 合并 intra + inter SPF 结果 */
        bgp_midr_merge_spf_results(&intra, &inter, prefix[i], &result);

        /* Layer 4: 策略匹配 (可选覆盖) */
        if (bgp_midr_pbr_match(bgp, prefix[i], &result))
            goto skip_cspf;  /* 策略已决定路径 */

        /* Layer 5: CSPF (可选) */
        if (bgp->midr_te_config.enable) {
            struct midr_cspf_result cspf = {};
            midr_cspf_compute(ted, prefix[i],
                              &bgp->midr_te_config.constraints, &cspf);
            midr_cspf_to_path_result(&cspf, &result);
        }

skip_cspf:
        /* Layer 6: 负载均衡权重 */
        midr_lb_compute_weights(&result);

        /* Layer 7: SRv6 封装决策 */
        if (result.group_ctx.is_cross_group)
            midr_srv6_assign_tunnel_sid(bgp, ted, &result);

        /* Layer 8: 下发到数据平面 */
        midr_zebra_route_add(bgp, prefix[i], &result);
    }

    /* Layer 9: 触发批量 flus */
    midr_zebra_route_update_deferred(bgp);
}
```

### 4.4 SRv6 与 TE 的协同

SRv6 和 TE 的协同体现在两个层面：

**层面 A: CSPF 选择 SID List**

```
TED 提供:
  ├── 节点 A 发布了 SID_A (End)
  ├── 节点 B 发布了 SID_B (End)
  └── 节点 C 发布了 SID_C (End.DT4)

CSPF 计算:
  ┌──────────────────────────────────────────────┐
  │  路径: R1 → R2 → R4 → R5                   │
  │                                              │
  │  TE 约束: delay < 10ms, bw > 100Mbps        │
  │                                              │
  │  SID List 构造:                              │
  │    从 TED 查 R2/R4/R5 发布的 SID:           │
  │    → [R2.End, R4.End, R5.End.DT4]           │
  └──────────────────────────────────────────────┘

LB 权重影响:
  多条 SRv6 路径 → 每条路径有不同 SID List + weight
  → 内核按 weight 均衡到不同 SRv6 隧道
```

**层面 B: LB 权重影响多隧道分发**

```c
/* 两条 SRv6 隧道, 不同延迟/带宽 */
struct midr_path_ext paths[2] = {
    /* 隧道 1: 低延迟 (5ms) 但带宽小 (50Mbps) */
    { .sid_list = {R2.End, R4.End.DT4},
      .sid_count = 2,
      .te_metric = 5000,     /* 5ms */
      .avail_bw = 50,
      .weight = 120,          /* 较低权重, 因带宽小 */
    },
    /* 隧道 2: 高延迟 (15ms) 但带宽大 (200Mbps) */
    { .sid_list = {R3.End, R5.End, R4.End.DT4},
      .sid_count = 3,
      .te_metric = 15000,    /* 15ms */
      .avail_bw = 200,
      .weight = 135,          /* 较高权重, 因带宽大 */
    },
};

/* 内核效果: 两条 SRv6 隧道, weight 120:135 ≈ 47:53 */
```

---

## 五、典型场景完整示例

### 5.1 场景: 跨 Group 低延迟路径

```
  配置:
    group 1: R1,R2,R3  (AS 65001)
    group 2: R4,R5,R6  (AS 65002)
    group 3: R7,R8,R9  (AS 65003)

    目的前缀: 10.0.0.0/24 (在 R9 上)
    TE 约束: max-delay 10ms, min-bandwidth 100Mbps
    LB 算法: delay (按延迟倒数加权)
```

### 5.2 完整操作流水

```
时间 | 操作                          | 模块               | 数据
─────┼───────────────────────────────┼────────────────────┼────────────
T+0  | R4-R8 链路延迟从 5ms→15ms   | ospfd              | LSA 更新
T+10 | ospfd → zebra → bgpd        | link_state.c       | LS_MSG_UPDATE
T+11 | bgpd TED 更新 edge(R4→R8)   | bgp_ls_ted.c       | delay=15ms
T+12 | BGP-LS NLRI 更新发布         | bgp_ls.c            | BGP UPDATE
T+12 | MIDR SPF 触发                 | bgp_midr_spf.c     | event 入队
T+13 | Group 内 SPF (Group 2)       | bgp_midr_spf.c     | 发现 R4-R8 变差
T+14 | Group 间 SPF                  | bgp_midr_spf.c     | 发现替代路径 R5-R7
T+15 | Policy 匹配 (color=100)      | bgp_midr_pbr.c     | 无匹配
T+15 | CSPF 计算                     | bgp_midr_cspf.c    │
     |  剪枝: delay>10ms 的链路      |                    | 排除 R4-R8
     |  K-SPF 找 2 条路径           |                    │
     |    path[0]: R1→R4→R5→R7→R9  |                    | delay=8ms,bw=150M
     |    path[1]: R1→R2→R4→R5→R7→R9|                   | delay=9ms,bw=120M
T+20 | SID List 构造                 | bgp_midr_cspf.c   │
     |    path[0]: [R4.End,R7.End,R9.End.DT4]          │
     |    path[1]: [R2.End,R4.End,R7.End,R9.End.DT4]   │
T+21 | LB 权重计算 (delay)           | bgp_midr_lb.c     │
     |    path[0]: (1/8)/(1/8+1/9)=0.529→weight=135   │
     |    path[1]: (1/9)/(1/8+1/9)=0.471→weight=120   │
T+22 | 封装模式: SRv6 + Cross-Group  | bgp_midr_zebra.c  |
     |    sid_count=3, is_cross_group=1                │
T+22 | midr_zebra_route_add()        | bgp_midr_zebra.c  | pending adds
T+122| 100ms 批量 flush              | bgp_midr_zebra.c  |
T+122| zclient_route_send()          | zclient.c         | ZAPI
T+123| zebra 处理                     | zebra_rib.c       | RIB 更新
T+124| Netlink 下发                   | rt_netlink.c      |
     | ip -6 route add 10.0.0.0/24                     │
     |   nexthop encap seg6 mode encap                 │
     |     segs [R4.End,R7.End,R9.End.DT4]             │
     |     via fc00:ab::4 weight 135                   │
     |   nexthop encap seg6 mode encap                 │
     |     segs [R2.End,R4.End,R7.End,R9.End.DT4]     │
     |     via fc00:ab::2 weight 120                   │
T+125| 转发生效                     | Kernel FIB       |
```

---

## 六、代码文件协同关系图

```
                            TED 数据源
                            ┌────────────┐
                            │ lib/       │
                            │ link_state │  ← 图数据结构
                            │ .c/.h      │  ← ls_parse/send_msg
                            └─────┬──────┘
                                  │ ZAPI OPAQUE
                                  ▼
                   ┌────────────────────────────┐
                   │ TED 管理 (bgp_ls_ted.c)     │
                   │ → ls_msg2vertex/edge/subnet│
                   │ → TED 增删改                │
                   │ → BGP-LS NLRI 产出          │
                   └────────────┬───────────────┘
                                │ TED 指针
                                ▼
        ┌──────────────────────────────────────────────────────┐
        │               MIDR 路由计算引擎                      │
        │                                                      │
        │  ┌────────────┐  ┌───────────┐  ┌──────────────┐   │
        │  │ midr_spf   │  │ midr_pbr  │  │ midr_cspf    │   │
        │  │ (SPF计算)  │  │ (策略匹配) │  │ (CSPF优化)   │   │
        │  │            │  │           │  │              │   │
        │  │ TED→路径   │  │ src/dst   │  │ TED+约束→    │   │
        │  │ →intra+inter│  │ →策略覆盖 │  │ K条最优路径  │   │
        │  └──────┬─────┘  └─────┬─────┘  └──────┬───────┘   │
        │         │              │               │           │
        │         └──────────────┴───────────────┘           │
        │                      │ midr_path_result            │
        │                      ▼                             │
        │  ┌─────────────────────────────────────────┐      │
        │  │   midr_lb (负载均衡权重计算)              │      │
        │  │   → group 权重 × path 权重 → final_weight │      │
        │  └──────────────────┬──────────────────────┘      │
        │                     │                             │
        │  ┌──────────────────┴──────────────────────┐      │
        │  │   midr_srv6 (SRv6 隧道决策)              │      │
        │  │   → 跨 group 时分配 SID List             │      │
        │  └──────────────────┬──────────────────────┘      │
        │                     │                             │
        └─────────────────────┼─────────────────────────────┘
                              │ midr_path_result (含所有信息)
                              ▼
        ┌──────────────────────────────────────────────────────┐
        │               midr_zebra.c (数据平面下发)           │
        │   midr_zebra_route_add()                            │
        │   ├── 模式检测                                       │
        │   ├── 填充 zapi_route + zapi_nexthop                │
        │   ├── 批量聚合 pending adds/dels                    │
        │   └── zclient_route_send() → zebra                  │
        └────────────────────────┬─────────────────────────────┘
                                 │ ZAPI
                                 ▼
        ┌──────────────────────────────────────────────────────┐
        │  zebra (全部复用, 不修改)                            │
        │  zapi_msg → zebra_rib → zebra_nhg → dplane → netlink│
        └──────────────────────────────────────────────────────┘
```

---

## 七、总结

| 层次 | 模块 | 输入 | 输出 | 触发条件 |
|------|------|------|------|---------|
| **L0 LSDB** | `lib/link_state` + `bgp_ls_ted.c` | ZAPI OPAQUE 消息 | TED (ls_ted) | IGP LSA/Sync 请求 |
| **L1 BGP-LS** | `bgp_ls.c` | TED | BGP-LS NLRI | TED 变化 |
| **L2 SPF** | `bgp_midr_spf.c` | TED + Group 配置 | intra/inter 路径 | TED 变化 |
| **L3 Policy** | `bgp_midr_pbr.c` | 策略配置 + SPF 结果 | 修改后的路径 | 策略配置/SPF |
| **L4 CSPF** | `bgp_midr_cspf.c` | TED + 约束 | K 条最优路径 | 用户配置 TE |
| **L5 LB** | `bgp_midr_lb.c` | 路径 + TE 度量 | 权重 (weight) | SPF/CSPF 完成 |
| **L6 Encaps** | `bgp_midr_srv6.c` | 路径 + Group | SID List | 跨 Group 需求 |
| **L7 DP** | `bgp_midr_zebra.c` | `midr_path_result` | ZAPI 消息 | 上述全部完成 |
| **L8 Batch** | `bgp_midr_zebra.c` | pending adds/dels | 批量 ZAPI | 100ms 定时器 |